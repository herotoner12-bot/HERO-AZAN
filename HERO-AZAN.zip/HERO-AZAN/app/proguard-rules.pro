# Room / WorkManager / Compose ship their own consumer rules.
# Adhan (com.batoulapps.adhan) is plain Java without reflection.
-keep class com.herotoner.heroazan.alarms.** { *; }
