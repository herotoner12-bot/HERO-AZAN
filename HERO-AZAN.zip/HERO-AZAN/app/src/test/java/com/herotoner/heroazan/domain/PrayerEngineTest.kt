package com.herotoner.heroazan.domain

import com.herotoner.heroazan.model.CalcMethodOption
import com.herotoner.heroazan.model.MadhabOption
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.model.PrayerCalcSettings
import com.herotoner.heroazan.model.PrayerOffsets
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

/**
 * Compares the Android engine (Adhan Java library) against reference values produced by
 * the independent JavaScript implementation (tools/gen_reference_times.js, npm adhan 4.x)
 * for Aleppo, Sheikh Maqsood, Ashrafiyah, Afrin, Damascus, Homs and Latakia.
 *
 * NOTE: this proves the two Adhan implementations agree. It does NOT replace comparing the
 * results with the official local (Awqaf) calendar, see README.
 */
class PrayerEngineTest {

    private val damascus: ZoneId = ZoneId.of("Asia/Damascus")

    private val reference: JSONObject by lazy {
        val stream = javaClass.classLoader!!.getResourceAsStream("reference_times.json")
        assertNotNull("reference_times.json missing from test resources", stream)
        JSONObject(stream!!.bufferedReader(Charsets.UTF_8).readText())
    }

    private fun method(key: String) = when (key) {
        "MWL" -> CalcMethodOption.MWL
        "EGYPTIAN" -> CalcMethodOption.EGYPTIAN
        "UMM_AL_QURA" -> CalcMethodOption.UMM_AL_QURA
        "KARACHI" -> CalcMethodOption.KARACHI
        else -> error("unknown method $key")
    }

    private fun secondsApart(a: Instant, b: Instant) = abs(Duration.between(a, b).seconds)

    @Test
    fun matchesReferenceImplementationWithinOneMinute() {
        val rows = reference.getJSONArray("times")
        assertTrue("reference file is empty", rows.length() > 100)
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val calc = PrayerCalcSettings(
                method = method(r.getString("method")),
                madhab = if (r.getString("madhab") == "HANAFI") MadhabOption.HANAFI else MadhabOption.SHAFI,
            )
            val t = PrayerEngine.compute(
                r.getDouble("lat"), r.getDouble("lon"), LocalDate.parse(r.getString("date")), damascus, calc,
            )
            val label = "${r.getString("place")} ${r.getString("date")} ${r.getString("method")} ${r.getString("madhab")}"
            fun check(name: String, actual: Instant) {
                val expected = Instant.parse(r.getString(name))
                assertTrue("$label $name expected=$expected actual=$actual", secondsApart(expected, actual) <= 60)
            }
            check("fajr", t.fajr)
            check("sunrise", t.sunrise)
            check("dhuhr", t.dhuhr)
            check("asr", t.asr)
            check("maghrib", t.maghrib)
            check("isha", t.isha)
        }
    }

    @Test
    fun prayersAreInChronologicalOrder() {
        val rows = reference.getJSONArray("times")
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val t = PrayerEngine.compute(
                r.getDouble("lat"), r.getDouble("lon"), LocalDate.parse(r.getString("date")), damascus,
                PrayerCalcSettings(method(r.getString("method"))),
            )
            assertTrue(t.fajr < t.sunrise && t.sunrise < t.dhuhr && t.dhuhr < t.asr && t.asr < t.maghrib && t.maghrib < t.isha)
        }
    }

    @Test
    fun allTimesAreWholeMinutes() {
        val t = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 12, 21), damascus, PrayerCalcSettings())
        listOf(t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha).forEach {
            assertEquals(0L, it.epochSecond % 60)
            assertEquals(0, it.nano)
        }
    }

    @Test
    fun hanafiAsrIsLaterThanShafiAsr() {
        val shafi = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 12, 21), damascus, PrayerCalcSettings(madhab = MadhabOption.SHAFI))
        val hanafi = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 12, 21), damascus, PrayerCalcSettings(madhab = MadhabOption.HANAFI))
        assertTrue(hanafi.asr > shafi.asr)
        assertEquals(shafi.fajr, hanafi.fajr)
        assertEquals(shafi.dhuhr, hanafi.dhuhr)
    }

    @Test
    fun manualOffsetsShiftOnlyTheChosenPrayer() {
        val date = LocalDate.of(2026, 6, 21)
        val base = PrayerEngine.compute(36.2, 37.16, date, damascus, PrayerCalcSettings())
        val shifted = PrayerEngine.compute(
            36.2, 37.16, date, damascus,
            PrayerCalcSettings(offsets = PrayerOffsets().with("fajr", 5).with("maghrib", -3)),
        )
        assertEquals(5 * 60L, Duration.between(base.fajr, shifted.fajr).seconds)
        assertEquals(-3 * 60L, Duration.between(base.maghrib, shifted.maghrib).seconds)
        assertEquals(base.dhuhr, shifted.dhuhr)
        assertEquals(base.isha, shifted.isha)
    }

    @Test
    fun offsetsAreClampedToThirtyMinutes() {
        assertEquals(30, PrayerOffsets().with("isha", 99).isha)
        assertEquals(-30, PrayerOffsets().with("isha", -99).isha)
    }

    @Test
    fun nextPrayerLogic() {
        val calc = PrayerCalcSettings()
        val date = LocalDate.of(2026, 12, 21)
        val t = PrayerEngine.compute(36.2, 37.16, date, damascus, calc)

        val beforeFajr = PrayerEngine.nextPrayer(t.fajr.minusSeconds(60), 36.2, 37.16, damascus, calc)
        assertEquals(Prayer.FAJR, beforeFajr.prayer)
        assertEquals(false, beforeFajr.isTomorrow)
        assertEquals(t.fajr, beforeFajr.time)

        val atDhuhr = PrayerEngine.nextPrayer(t.dhuhr, 36.2, 37.16, damascus, calc)
        assertEquals(Prayer.ASR, atDhuhr.prayer)

        val afterIsha = PrayerEngine.nextPrayer(t.isha.plusSeconds(60), 36.2, 37.16, damascus, calc)
        val tomorrow = PrayerEngine.compute(36.2, 37.16, date.plusDays(1), damascus, calc)
        assertEquals(Prayer.FAJR, afterIsha.prayer)
        assertEquals(true, afterIsha.isTomorrow)
        assertEquals(tomorrow.fajr, afterIsha.time)
    }

    @Test
    fun currentPrayerLogic() {
        val calc = PrayerCalcSettings()
        val t = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 12, 21), damascus, calc)
        fun cur(i: Instant) = PrayerEngine.currentPrayer(i, 36.2, 37.16, damascus, calc)
        assertEquals(Prayer.FAJR, cur(t.fajr.plusSeconds(1)))
        assertNull(cur(t.sunrise.plusSeconds(1)))
        assertEquals(Prayer.DHUHR, cur(t.dhuhr.plusSeconds(1)))
        assertEquals(Prayer.ASR, cur(t.asr.plusSeconds(1)))
        assertEquals(Prayer.MAGHRIB, cur(t.maghrib.plusSeconds(1)))
        assertEquals(Prayer.ISHA, cur(t.isha.plusSeconds(1)))
    }

    @Test
    fun upcomingPerPrayerIsAlwaysInTheFutureWithinAboutADay() {
        val calc = PrayerCalcSettings()
        val now = Instant.parse("2026-12-21T11:30:00Z")
        val up = PrayerEngine.upcomingPerPrayer(now, 36.2, 37.16, damascus, calc)
        assertEquals(5, up.size)
        for ((p, at) in up) {
            assertTrue("$p must be after now", at > now)
            assertTrue("$p must be within 25h", Duration.between(now, at).toHours() <= 25)
        }
    }

    @Test
    fun syriaHasNoDaylightSavingInTheJdkTimeZoneData() {
        val summer = damascus.rules.getOffset(Instant.parse("2026-06-21T09:00:00Z"))
        val winter = damascus.rules.getOffset(Instant.parse("2026-12-21T09:00:00Z"))
        assertEquals("+03:00", summer.id)
        assertEquals(summer, winter)
    }

    @Test
    fun daylightSavingChangesDisplayedHourButNotTheComputedInstant() {
        // Berlin: clocks change on 2027-03-28. Solar noon stays ~11:1x UTC, local hour goes 12 -> 13.
        val berlin = ZoneId.of("Europe/Berlin")
        val calc = PrayerCalcSettings()
        val before = PrayerEngine.compute(52.52, 13.405, LocalDate.of(2027, 3, 27), berlin, calc)
        val after = PrayerEngine.compute(52.52, 13.405, LocalDate.of(2027, 3, 29), berlin, calc)
        assertEquals(12, before.dhuhr.atZone(berlin).hour)
        assertEquals(13, after.dhuhr.atZone(berlin).hour)
        // the instant does not depend on the zone argument
        val sameInstantOtherZone = PrayerEngine.compute(52.52, 13.405, LocalDate.of(2027, 3, 29), ZoneId.of("UTC"), calc)
        assertEquals(after.dhuhr, sameInstantOtherZone.dhuhr)
    }

    @Test
    fun dayChangeMovesTimesByAtMostAFewMinutes() {
        val calc = PrayerCalcSettings()
        val d1 = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 10, 1), damascus, calc)
        val d2 = PrayerEngine.compute(36.2, 37.16, LocalDate.of(2026, 10, 2), damascus, calc)
        val shift = abs(Duration.between(d1.fajr, d2.fajr.minus(Duration.ofDays(1))).seconds)
        assertTrue("fajr shift between consecutive days should be small, was ${shift}s", shift in 0..300)
    }
}
