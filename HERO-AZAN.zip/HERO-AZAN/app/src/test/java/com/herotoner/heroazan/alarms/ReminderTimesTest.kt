package com.herotoner.heroazan.alarms

import com.herotoner.heroazan.model.AdhanChoice
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.ZoneId

class ReminderTimesTest {
    private val damascus = ZoneId.of("Asia/Damascus") // UTC+3, no DST

    @Test
    fun nextDailyIsLaterTodayWhenTimeHasNotPassed() {
        val now = Instant.parse("2026-11-10T03:00:00Z") // 06:00 local
        val at = ReminderTimes.nextDaily(now, 6, 30, damascus)
        assertEquals(Instant.parse("2026-11-10T03:30:00Z"), at)
    }

    @Test
    fun nextDailyRollsToTomorrowWhenTimePassedOrEqual() {
        val now = Instant.parse("2026-11-10T03:30:00Z") // exactly 06:30 local
        val at = ReminderTimes.nextDaily(now, 6, 30, damascus)
        assertEquals(Instant.parse("2026-11-11T03:30:00Z"), at)
        assertTrue(at.isAfter(now))
    }

    @Test
    fun nextDailyKeepsLocalWallClockAcrossDaylightSavingChange() {
        // Berlin switches to summer time on 2027-03-28 (02:00 -> 03:00): 08:00 local must stay 08:00 local.
        val berlin = ZoneId.of("Europe/Berlin")
        val now = Instant.parse("2027-03-27T12:00:00Z")
        val at = ReminderTimes.nextDaily(now, 8, 0, berlin)
        assertEquals(8, at.atZone(berlin).hour)
        assertEquals(28, at.atZone(berlin).dayOfMonth)
        assertEquals(Instant.parse("2027-03-28T06:00:00Z"), at) // 08:00 CEST (UTC+2)
    }

    @Test
    fun adhanChoiceEncodingRoundTrips() {
        listOf(
            AdhanChoice.DEFAULT,
            AdhanChoice(AdhanChoice.Type.ASSET, "makkah"),
            AdhanChoice(AdhanChoice.Type.CUSTOM, "content://media/external/audio/media/42"),
        ).forEach { assertEquals(it, AdhanChoice.decode(it.encode())) }
        assertEquals(AdhanChoice.DEFAULT, AdhanChoice.decode(null))
        assertEquals(AdhanChoice.DEFAULT, AdhanChoice.decode("garbage"))
    }
}
