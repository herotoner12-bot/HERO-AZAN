package com.herotoner.heroazan.domain

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

class QiblaAndFormatsTest {

    @Test
    fun qiblaBearingMatchesReferenceWithinOneTenthOfADegree() {
        val stream = javaClass.classLoader!!.getResourceAsStream("reference_times.json")!!
        val rows = JSONObject(stream.bufferedReader(Charsets.UTF_8).readText()).getJSONArray("qibla")
        assertTrue(rows.length() >= 7)
        for (i in 0 until rows.length()) {
            val r = rows.getJSONObject(i)
            val mine = QiblaCalculator.bearing(r.getDouble("lat"), r.getDouble("lon"))
            val diff = abs(QiblaCalculator.signedDelta(mine, r.getDouble("bearing")))
            assertTrue("${r.getString("place")}: mine=$mine ref=${r.getDouble("bearing")}", diff < 0.1)
        }
    }

    @Test
    fun qiblaFromAleppoPointsSouthSouthEast() {
        val b = QiblaCalculator.bearing(36.2, 37.16)
        assertTrue("bearing $b", b in 165.0..175.0)
        assertEquals("جنوب", QiblaCalculator.cardinalAr(b))
    }

    @Test
    fun qiblaFromTheKaabaItselfDoesNotCrash() {
        val b = QiblaCalculator.bearing(QiblaCalculator.KAABA_LATITUDE, QiblaCalculator.KAABA_LONGITUDE)
        assertTrue(b in 0.0..360.0)
        assertEquals(0.0, QiblaCalculator.distanceKm(QiblaCalculator.KAABA_LATITUDE, QiblaCalculator.KAABA_LONGITUDE), 0.001)
    }

    @Test
    fun distanceAleppoToKaabaIsPlausible() {
        val km = QiblaCalculator.distanceKm(36.2, 37.16)
        // ~1643 km north-south + ~258 km east-west => ~1663 km (checked by hand)
        assertTrue("distance $km", km in 1640.0..1690.0)
    }

    @Test
    fun signedDeltaWrapsAroundNorth() {
        assertEquals(20.0, QiblaCalculator.signedDelta(350.0, 10.0), 1e-9)
        assertEquals(-20.0, QiblaCalculator.signedDelta(10.0, 350.0), 1e-9)
        assertEquals(0.0, QiblaCalculator.signedDelta(123.0, 123.0), 1e-9)
    }

    @Test
    fun hijriDatesFollowUmmAlQura() {
        // Verified with the JDK's Umm al-Qura chronology (java.time.chrono.HijrahChronology)
        assertEquals("1 محرّم 1448 هـ", ArabicFormats.hijri(LocalDate.of(2026, 6, 16)))
        assertEquals("29 ذو الحجة 1447 هـ", ArabicFormats.hijri(LocalDate.of(2026, 6, 15)))
        assertEquals("30 جمادى الأولى 1448 هـ", ArabicFormats.hijri(LocalDate.of(2026, 11, 10)))
    }

    @Test
    fun hijriAdjustmentShiftsByDays() {
        assertEquals("2 محرّم 1448 هـ", ArabicFormats.hijri(LocalDate.of(2026, 6, 16), adjustDays = 1))
        assertEquals("29 ذو الحجة 1447 هـ", ArabicFormats.hijri(LocalDate.of(2026, 6, 16), adjustDays = -1))
    }

    @Test
    fun gregorianUsesSyrianMonthNames() {
        assertEquals("الثلاثاء، 10 تشرين الثاني 2026", ArabicFormats.gregorian(LocalDate.of(2026, 11, 10)))
        assertEquals("الجمعة، 1 كانون الثاني 2027", ArabicFormats.gregorian(LocalDate.of(2027, 1, 1)))
    }

    @Test
    fun clockFormats() {
        val zone = ZoneId.of("Asia/Damascus")
        val i = Instant.parse("2026-12-21T03:06:00Z") // 06:06 local
        assertEquals("6:06 ص", ArabicFormats.clock(i, zone, use24h = false))
        assertEquals("06:06", ArabicFormats.clock(i, zone, use24h = true))
        val noon = Instant.parse("2026-12-21T09:30:00Z") // 12:30 local
        assertEquals("12:30 م", ArabicFormats.clock(noon, zone, use24h = false))
        val midnight = Instant.parse("2026-12-20T21:05:00Z") // 00:05 local
        assertEquals("12:05 ص", ArabicFormats.clock(midnight, zone, use24h = false))
    }

    @Test
    fun countdownFormat() {
        assertEquals("00:00:00", ArabicFormats.countdown(-5))
        assertEquals("01:02:03", ArabicFormats.countdown(3723))
        assertEquals("12:00:00", ArabicFormats.countdown(43200))
    }

    @Test
    fun remainingWords() {
        assertEquals("5 دقيقة", ArabicFormats.remainingWords(300))
        assertEquals("2 ساعة", ArabicFormats.remainingWords(7200))
        assertEquals("1 ساعة و1 دقيقة", ArabicFormats.remainingWords(3601))
    }
}
