package com.herotoner.heroazan.alarms

import com.herotoner.heroazan.data.ReminderEntity
import com.herotoner.heroazan.model.Prayer

enum class ReminderKind(val arabic: String, val destination: String?) {
    MORNING_ADHKAR("أذكار الصباح", "adhkar"),
    EVENING_ADHKAR("أذكار المساء", "adhkar"),
    QURAN("قراءة القرآن", "quran"),
    PRAYER_BEFORE("تذكير بالصلاة", "prayer"),
    CUSTOM("تذكير شخصي", null);

    companion object {
        fun fromName(name: String?): ReminderKind = entries.firstOrNull { it.name == name } ?: CUSTOM
    }
}

/** Reminders created on first launch (all switched off until the user enables them). */
object DefaultReminders {
    fun all(): List<ReminderEntity> = listOf(
        ReminderEntity(kind = ReminderKind.MORNING_ADHKAR.name, title = "أذكار الصباح",
            body = "حان وقت أذكار الصباح، ابدأ يومك بذكر الله", hour = 6, minute = 30, enabled = false, prayerKey = null, minutesBefore = 0),
        ReminderEntity(kind = ReminderKind.EVENING_ADHKAR.name, title = "أذكار المساء",
            body = "حان وقت أذكار المساء", hour = 17, minute = 30, enabled = false, prayerKey = null, minutesBefore = 0),
        ReminderEntity(kind = ReminderKind.QURAN.name, title = "ورد القرآن",
            body = "خصّص وقتاً لقراءة وردك من القرآن الكريم", hour = 21, minute = 0, enabled = false, prayerKey = null, minutesBefore = 0),
        ReminderEntity(kind = ReminderKind.PRAYER_BEFORE.name, title = "تذكير بصلاة المغرب",
            body = "اقترب موعد صلاة المغرب", hour = 0, minute = 0, enabled = false, prayerKey = Prayer.MAGHRIB.key, minutesBefore = 15),
    )
}
