package com.herotoner.heroazan.alarms

import android.content.Context
import android.net.Uri
import com.herotoner.heroazan.model.AdhanChoice
import org.json.JSONObject

/** An adhan recording bundled in assets/adhan/ and described in assets/adhan/manifest.json. */
data class AdhanAsset(
    val id: String,
    val name: String,
    val file: String,
    val source: String,
    val license: String,
)

sealed class AdhanSource {
    data class Asset(val path: String) : AdhanSource()
    data class Custom(val uri: Uri) : AdhanSource()
}

/**
 * Lists the adhan files shipped with the app. The project does not bundle any recording by
 * default (a licence has to be confirmed for each one) -- see README.md > الأذان.
 */
class AdhanLibrary(private val context: Context) {

    fun available(): List<AdhanAsset> = runCatching {
        val text = context.assets.open("adhan/manifest.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONObject(text).getJSONArray("adhans")
        val present = context.assets.list("adhan")?.toSet().orEmpty()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val file = o.getString("file")
            if (file !in present) null
            else AdhanAsset(
                id = o.getString("id"),
                name = o.getString("name"),
                file = file,
                source = o.optString("source"),
                license = o.optString("license"),
            )
        }
    }.getOrDefault(emptyList())

    /** Resolves the user's choice to something playable, or null (-> fallback to notification sound). */
    fun resolve(choice: AdhanChoice): AdhanSource? = when (choice.type) {
        AdhanChoice.Type.ASSET -> available().firstOrNull { it.id == choice.value }
            ?.let { AdhanSource.Asset("adhan/${it.file}") }
        AdhanChoice.Type.CUSTOM -> {
            val uri = runCatching { Uri.parse(choice.value) }.getOrNull()
            if (uri != null && canRead(uri)) AdhanSource.Custom(uri) else null
        }
        AdhanChoice.Type.DEFAULT -> available().firstOrNull()?.let { AdhanSource.Asset("adhan/${it.file}") }
    }

    private fun canRead(uri: Uri): Boolean = runCatching {
        context.contentResolver.openInputStream(uri)?.use { true } ?: false
    }.getOrDefault(false)
}
