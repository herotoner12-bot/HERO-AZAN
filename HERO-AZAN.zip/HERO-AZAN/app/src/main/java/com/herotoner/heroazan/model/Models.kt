package com.herotoner.heroazan.model

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Madhab
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** The five daily prayers (sunrise is shown separately, it is not a prayer). */
enum class Prayer(val key: String, val arabic: String) {
    FAJR("fajr", "الفجر"),
    DHUHR("dhuhr", "الظهر"),
    ASR("asr", "العصر"),
    MAGHRIB("maghrib", "المغرب"),
    ISHA("isha", "العشاء");

    companion object {
        fun fromKey(key: String?): Prayer? = entries.firstOrNull { it.key == key }
    }
}

data class DayPrayerTimes(
    val date: LocalDate,
    val zone: ZoneId,
    val fajr: Instant,
    val sunrise: Instant,
    val dhuhr: Instant,
    val asr: Instant,
    val maghrib: Instant,
    val isha: Instant,
) {
    fun timeOf(prayer: Prayer): Instant = when (prayer) {
        Prayer.FAJR -> fajr
        Prayer.DHUHR -> dhuhr
        Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib
        Prayer.ISHA -> isha
    }
}

data class NextPrayer(val prayer: Prayer, val time: Instant, val isTomorrow: Boolean)

/** Manual minute corrections added to each computed time (user-editable). */
data class PrayerOffsets(
    val fajr: Int = 0,
    val sunrise: Int = 0,
    val dhuhr: Int = 0,
    val asr: Int = 0,
    val maghrib: Int = 0,
    val isha: Int = 0,
) {
    fun of(key: String): Int = when (key) {
        "fajr" -> fajr
        "sunrise" -> sunrise
        "dhuhr" -> dhuhr
        "asr" -> asr
        "maghrib" -> maghrib
        "isha" -> isha
        else -> 0
    }

    fun with(key: String, minutes: Int): PrayerOffsets {
        val v = minutes.coerceIn(-MAX_MINUTES, MAX_MINUTES)
        return when (key) {
            "fajr" -> copy(fajr = v)
            "sunrise" -> copy(sunrise = v)
            "dhuhr" -> copy(dhuhr = v)
            "asr" -> copy(asr = v)
            "maghrib" -> copy(maghrib = v)
            "isha" -> copy(isha = v)
            else -> this
        }
    }

    companion object {
        const val MAX_MINUTES = 30
    }
}

/** Calculation methods offered to the user. Angles are those of the Adhan library. */
enum class CalcMethodOption(
    val id: String,
    val arabic: String,
    val details: String,
    val method: CalculationMethod,
) {
    MWL("mwl", "رابطة العالم الإسلامي", "الفجر 18° • العشاء 17°", CalculationMethod.MUSLIM_WORLD_LEAGUE),
    EGYPTIAN("egyptian", "الهيئة المصرية العامة للمساحة", "الفجر 19.5° • العشاء 17.5°", CalculationMethod.EGYPTIAN),
    KARACHI("karachi", "جامعة العلوم الإسلامية - كراتشي", "الفجر 18° • العشاء 18°", CalculationMethod.KARACHI),
    UMM_AL_QURA("umm_al_qura", "جامعة أم القرى - مكة المكرمة", "الفجر 18.5° • العشاء بعد المغرب بـ 90 دقيقة", CalculationMethod.UMM_AL_QURA),
    DUBAI("dubai", "دبي", "الفجر 18.2° • العشاء 18.2°", CalculationMethod.DUBAI),
    NORTH_AMERICA("north_america", "الجمعية الإسلامية لأمريكا الشمالية (ISNA)", "الفجر 15° • العشاء 15°", CalculationMethod.NORTH_AMERICA),
    KUWAIT("kuwait", "الكويت", "الفجر 18° • العشاء 17.5°", CalculationMethod.KUWAIT),
    QATAR("qatar", "قطر", "الفجر 18° • العشاء بعد المغرب بـ 90 دقيقة", CalculationMethod.QATAR);

    companion object {
        val DEFAULT = MWL
        fun fromId(id: String?): CalcMethodOption = entries.firstOrNull { it.id == id } ?: DEFAULT
    }
}

enum class MadhabOption(val id: String, val arabic: String, val details: String, val madhab: Madhab) {
    SHAFI("shafi", "الجمهور (الشافعي ومن وافقه)", "العصر عندما يصير ظل الشيء مثله", Madhab.SHAFI),
    HANAFI("hanafi", "الحنفي", "العصر عندما يصير ظل الشيء مثليه", Madhab.HANAFI);

    companion object {
        fun fromId(id: String?): MadhabOption = entries.firstOrNull { it.id == id } ?: SHAFI
    }
}

data class PrayerCalcSettings(
    val method: CalcMethodOption = CalcMethodOption.DEFAULT,
    val madhab: MadhabOption = MadhabOption.SHAFI,
    val offsets: PrayerOffsets = PrayerOffsets(),
)

enum class LocationSource { PRESET, GPS, MANUAL }

data class UserLocation(
    val id: String,
    val govAr: String?,
    val cityAr: String,
    val areaAr: String?,
    val latitude: Double,
    val longitude: Double,
    /** null = follow the device time zone */
    val zoneId: String?,
    val source: LocationSource,
) {
    val displayName: String
        get() = listOfNotNull(govAr, cityAr, areaAr).filter { it.isNotBlank() }.distinct().joinToString("، ")

    fun zone(): ZoneId =
        zoneId?.let { runCatching { ZoneId.of(it) }.getOrNull() } ?: ZoneId.systemDefault()
}

/** What happens when a prayer time arrives. */
enum class AlertMode(val arabic: String) {
    ADHAN_FULL("أذان كامل"),
    SHORT_ALERT("تنبيه قصير"),
    SILENT("إشعار صامت"),
    OFF("إيقاف");

    companion object {
        fun fromName(name: String?): AlertMode = entries.firstOrNull { it.name == name } ?: ADHAN_FULL
    }
}

/** Which audio is played for the full adhan. */
data class AdhanChoice(val type: Type, val value: String = "") {
    enum class Type { DEFAULT, ASSET, CUSTOM }

    fun encode(): String = when (type) {
        Type.DEFAULT -> "default"
        Type.ASSET -> "asset:$value"
        Type.CUSTOM -> "custom:$value"
    }

    companion object {
        val DEFAULT = AdhanChoice(Type.DEFAULT)

        fun decode(raw: String?): AdhanChoice = when {
            raw == null || raw == "default" -> DEFAULT
            raw.startsWith("asset:") -> AdhanChoice(Type.ASSET, raw.removePrefix("asset:"))
            raw.startsWith("custom:") -> AdhanChoice(Type.CUSTOM, raw.removePrefix("custom:"))
            else -> DEFAULT
        }
    }
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val location: UserLocation? = null,
    val methodId: String = CalcMethodOption.DEFAULT.id,
    val madhabId: String = MadhabOption.SHAFI.id,
    val offsets: PrayerOffsets = PrayerOffsets(),
    val alertModes: Map<Prayer, AlertMode> = Prayer.entries.associateWith { AlertMode.ADHAN_FULL },
    val adhanChoices: Map<Prayer, AdhanChoice> = Prayer.entries.associateWith { AdhanChoice.DEFAULT },
    val adhanVolume: Float = 1f,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val fontScale: Float = 1f,
    val quranFontSize: Int = 26,
    val use24h: Boolean = false,
    val hijriAdjust: Int = 0,
    val lastSurah: Int = 1,
    val lastAyah: Int = 1,
) {
    val calc: PrayerCalcSettings
        get() = PrayerCalcSettings(
            method = CalcMethodOption.fromId(methodId),
            madhab = MadhabOption.fromId(madhabId),
            offsets = offsets,
        )

    fun alertModeOf(prayer: Prayer): AlertMode = alertModes[prayer] ?: AlertMode.ADHAN_FULL
    fun adhanChoiceOf(prayer: Prayer): AdhanChoice = adhanChoices[prayer] ?: AdhanChoice.DEFAULT
}
