package com.herotoner.heroazan.domain

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Qibla = initial great-circle bearing from the user to the Kaaba (clockwise from
 * TRUE north). The Kaaba coordinates are the ones used by the Adhan library.
 */
object QiblaCalculator {
    const val KAABA_LATITUDE = 21.4225241
    const val KAABA_LONGITUDE = 39.8261818
    private const val EARTH_RADIUS_KM = 6371.0088

    /** Bearing in degrees [0, 360). */
    fun bearing(latitude: Double, longitude: Double): Double {
        val phi1 = Math.toRadians(latitude)
        val phi2 = Math.toRadians(KAABA_LATITUDE)
        val dLon = Math.toRadians(KAABA_LONGITUDE - longitude)
        val y = sin(dLon) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /** Great-circle distance to the Kaaba in kilometres (haversine). */
    fun distanceKm(latitude: Double, longitude: Double): Double {
        val phi1 = Math.toRadians(latitude)
        val phi2 = Math.toRadians(KAABA_LATITUDE)
        val dPhi = phi2 - phi1
        val dLam = Math.toRadians(KAABA_LONGITUDE - longitude)
        val a = sin(dPhi / 2) * sin(dPhi / 2) + cos(phi1) * cos(phi2) * sin(dLam / 2) * sin(dLam / 2)
        return 2 * EARTH_RADIUS_KM * atan2(sqrt(a), sqrt(1 - a))
    }

    /** Smallest signed angle (-180..180] from [heading] to [target], both in degrees. */
    fun signedDelta(heading: Double, target: Double): Double {
        var d = (target - heading) % 360.0
        if (d > 180.0) d -= 360.0
        if (d <= -180.0) d += 360.0
        return d
    }

    /** Arabic cardinal / intercardinal name for a bearing. */
    fun cardinalAr(bearing: Double): String {
        val names = arrayOf("شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب")
        val idx = (((bearing % 360.0) + 360.0) % 360.0 / 45.0 + 0.5).toInt() % 8
        return names[idx]
    }
}
