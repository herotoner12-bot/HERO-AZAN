package com.herotoner.heroazan.alarms

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AdhanChoice
import com.herotoner.heroazan.model.Prayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service (type mediaPlayback) that plays the adhan while the screen is off. */
class AdhanService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var player: AdhanPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfSafely()
            return START_NOT_STICKY
        }
        val prayer = Prayer.fromKey(intent?.getStringExtra(EXTRA_PRAYER)) ?: run {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        // Must go to the foreground within seconds of startForegroundService().
        ServiceCompat.startForeground(
            this,
            Notifications.ID_ADHAN_PLAYBACK,
            Notifications.adhanPlaybackNotification(this, prayer, null),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
        )
        acquireWakeLock()

        val app = heroApp
        scope.launch {
            val settings = app.settings.current()
            val choice = AdhanChoice.decode(intent?.getStringExtra(EXTRA_CHOICE) ?: settings.adhanChoiceOf(prayer).encode())
            val p = AdhanPlayer(this@AdhanService, app.adhanLibrary).also { player = it }
            val realAdhan = p.play(choice, settings.adhanVolume) { stopSelfSafely() }
            if (!realAdhan) {
                // No licensed recording / readable file: be honest in the notification.
                val nm = androidx.core.app.NotificationManagerCompat.from(this@AdhanService)
                runCatching {
                    nm.notify(
                        Notifications.ID_ADHAN_PLAYBACK,
                        Notifications.adhanPlaybackNotification(
                            this@AdhanService, prayer,
                            "لا يوجد ملف أذان مضاف، تم استخدام نغمة التنبيه. أضف ملف أذان من الإعدادات.",
                        ),
                    )
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "heroazan:adhan").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // safety timeout: 10 minutes
        }
    }

    private fun stopSelfSafely() {
        player?.stop()
        player = null
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        player?.stop()
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.herotoner.heroazan.STOP_ADHAN"
        const val EXTRA_PRAYER = "prayer"
        const val EXTRA_CHOICE = "choice"

        fun intent(context: Context, prayer: Prayer): Intent =
            Intent(context, AdhanService::class.java).putExtra(EXTRA_PRAYER, prayer.key)
    }
}
