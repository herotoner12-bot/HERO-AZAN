package com.herotoner.heroazan.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herotoner.heroazan.alarms.AdhanPlayer
import com.herotoner.heroazan.alarms.AdhanService
import com.herotoner.heroazan.alarms.DefaultReminders
import com.herotoner.heroazan.alarms.ReminderKind
import com.herotoner.heroazan.data.AdhkarProgressEntity
import com.herotoner.heroazan.data.FavoriteAyahEntity
import com.herotoner.heroazan.data.FavoriteLocationEntity
import com.herotoner.heroazan.data.LocationsRepository
import com.herotoner.heroazan.data.ReminderEntity
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AdhanChoice
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.LocationSource
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.model.ThemeMode
import com.herotoner.heroazan.model.UserLocation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate

sealed interface GpsResult {
    data class Success(val location: UserLocation) : GpsResult
    data object NoPermission : GpsResult
    data object LocationOff : GpsResult
    data object Failed : GpsResult
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application.heroApp

    /** null until DataStore delivered the first value (avoids flashing default settings). */
    val settings: StateFlow<AppSettings?> = app.settings.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _now = MutableStateFlow(Instant.now())
    val now: StateFlow<Instant> = _now

    val favoriteLocations = app.database.favoriteLocations().observeAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favoriteAyahs = app.database.favoriteAyahs().observeAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val reminders = app.database.reminders().observeAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Incremented every time the app comes to the foreground (permission states may have changed). */
    val resumeTick = MutableStateFlow(0)

    private var previewPlayer: AdhanPlayer? = null
    private val _previewing = MutableStateFlow<String?>(null)
    val previewing: StateFlow<String?> = _previewing

    init {
        // 1 Hz clock for the countdown.
        viewModelScope.launch {
            while (true) {
                _now.value = Instant.now()
                delay(1000)
            }
        }
        // Re-program alarms whenever something that affects them changes.
        viewModelScope.launch {
            app.settings.settings
                .map { s -> listOf(s.location, s.methodId, s.madhabId, s.offsets, s.alertModes) }
                .distinctUntilChanged()
                .collect { app.scheduler.rescheduleAll() }
        }
        viewModelScope.launch { seedRemindersOnce() }
    }

    private suspend fun seedRemindersOnce() {
        val prefs = getApplication<Application>().getSharedPreferences("meta", 0)
        if (!prefs.getBoolean("reminders_seeded", false)) {
            val dao = app.database.reminders()
            if (dao.count() == 0) DefaultReminders.all().forEach { dao.upsert(it) }
            prefs.edit().putBoolean("reminders_seeded", true).apply()
        }
    }

    // ------------------------------------------------------------ location

    fun setLocation(location: UserLocation) = viewModelScope.launch { app.settings.setLocation(location) }

    fun saveFavorite(location: UserLocation) = viewModelScope.launch {
        app.database.favoriteLocations().upsert(
            FavoriteLocationEntity(
                id = location.id, govAr = location.govAr, cityAr = location.cityAr, areaAr = location.areaAr,
                latitude = location.latitude, longitude = location.longitude, zoneId = location.zoneId,
                source = location.source.name, createdAt = System.currentTimeMillis(),
            ),
        )
    }

    fun deleteFavorite(id: String) = viewModelScope.launch { app.database.favoriteLocations().delete(id) }

    suspend fun fetchGps(): GpsResult {
        val gps = app.gps
        if (!gps.hasPermission()) return GpsResult.NoPermission
        if (!gps.isLocationEnabled()) return GpsResult.LocationOff
        val fix = gps.currentLocation() ?: return GpsResult.Failed
        val data = app.locations.load()
        val nearest = app.locations.nearestCity(data.places, fix.latitude, fix.longitude)
        val gov = nearest?.first?.let { p -> data.governorates.firstOrNull { it.id == p.gov } }
        val label = nearest?.let { "قرب ${it.first.ar}" } ?: "موقعي الحالي"
        return GpsResult.Success(
            UserLocation(
                id = "gps",
                govAr = gov?.ar,
                cityAr = label,
                areaAr = null,
                latitude = fix.latitude,
                longitude = fix.longitude,
                zoneId = null, // follow the device time zone
                source = LocationSource.GPS,
            ),
        )
    }

    // ------------------------------------------------------------ calculation settings

    fun setMethod(id: String) = viewModelScope.launch { app.settings.setMethod(id) }
    fun setMadhab(id: String) = viewModelScope.launch { app.settings.setMadhab(id) }
    fun setOffset(key: String, minutes: Int) = viewModelScope.launch { app.settings.setOffset(key, minutes) }
    fun resetOffsets() = viewModelScope.launch { app.settings.resetOffsets() }

    // ------------------------------------------------------------ adhan

    fun setAlertMode(prayer: Prayer, mode: AlertMode) = viewModelScope.launch { app.settings.setAlertMode(prayer, mode) }
    fun setAllAlertModes(mode: AlertMode) = viewModelScope.launch { app.settings.setAllAlertModes(mode) }
    fun setAdhanChoice(prayer: Prayer, choice: AdhanChoice) = viewModelScope.launch { app.settings.setAdhanChoice(prayer, choice) }
    fun setAdhanChoiceForAll(choice: AdhanChoice) = viewModelScope.launch { app.settings.setAdhanChoiceForAll(choice) }
    fun setVolume(v: Float) = viewModelScope.launch { app.settings.setVolume(v) }

    fun availableAdhans() = app.adhanLibrary.available()

    /** Keeps read access to a user-picked audio file across restarts. */
    fun persistCustomAudio(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun previewAdhan(key: String, choice: AdhanChoice, volume: Float) {
        stopPreview()
        val player = AdhanPlayer(getApplication(), app.adhanLibrary)
        previewPlayer = player
        _previewing.value = key
        val real = player.play(choice, volume) { _previewing.value = null }
        if (!real) lastPreviewFallback.value = true
    }

    val lastPreviewFallback = MutableStateFlow(false)

    fun stopPreview() {
        previewPlayer?.stop()
        previewPlayer = null
        _previewing.value = null
    }

    /** Runs the REAL path (foreground service + notification) for a prayer, like at prayer time. */
    fun testAdhanService(prayer: Prayer) {
        val ctx = getApplication<Application>()
        runCatching { ContextCompat.startForegroundService(ctx, AdhanService.intent(ctx, prayer)) }
    }

    fun stopAdhanService() {
        val ctx = getApplication<Application>()
        ctx.startService(Intent(ctx, AdhanService::class.java).setAction(AdhanService.ACTION_STOP))
    }

    // ------------------------------------------------------------ appearance

    fun setTheme(mode: ThemeMode) = viewModelScope.launch { app.settings.setTheme(mode) }
    fun setFontScale(v: Float) = viewModelScope.launch { app.settings.setFontScale(v) }
    fun setQuranFontSize(v: Int) = viewModelScope.launch { app.settings.setQuranFontSize(v) }
    fun setUse24h(v: Boolean) = viewModelScope.launch { app.settings.setUse24h(v) }
    fun setHijriAdjust(v: Int) = viewModelScope.launch { app.settings.setHijriAdjust(v) }

    // ------------------------------------------------------------ quran

    fun setLastRead(surah: Int, ayah: Int) = viewModelScope.launch { app.settings.setLastRead(surah, ayah) }

    fun toggleFavoriteAyah(surah: Int, ayah: Int, isFav: Boolean) = viewModelScope.launch {
        val dao = app.database.favoriteAyahs()
        if (isFav) dao.delete(surah, ayah) else dao.upsert(FavoriteAyahEntity(surah, ayah, System.currentTimeMillis()))
    }

    // ------------------------------------------------------------ adhkar

    private fun dayKey(): Long = LocalDate.now().toEpochDay()

    fun adhkarProgress(sectionId: String) = app.database.adhkarProgress().observeSection(sectionId)
        .map { rows -> rows.filter { it.dayKey == dayKey() }.associate { it.itemIndex to it.count } }

    fun setAdhkarCount(sectionId: String, index: Int, count: Int) = viewModelScope.launch {
        app.database.adhkarProgress().upsert(AdhkarProgressEntity(sectionId, index, count, dayKey()))
    }

    fun resetAdhkar(sectionId: String) = viewModelScope.launch { app.database.adhkarProgress().clearSection(sectionId) }

    // ------------------------------------------------------------ reminders

    fun saveReminder(r: ReminderEntity) = viewModelScope.launch {
        app.database.reminders().upsert(r)
        app.scheduler.rescheduleAll()
    }

    fun deleteReminder(id: Int) = viewModelScope.launch {
        app.database.reminders().delete(id)
        app.scheduler.rescheduleAll()
    }

    fun reminderKindLabel(kind: String) = ReminderKind.fromName(kind).arabic

    fun canScheduleExact() = app.scheduler.canScheduleExact()

    fun refreshAlarms() = viewModelScope.launch { app.scheduler.rescheduleAll() }

    val locationsRepo: LocationsRepository get() = app.locations

    override fun onCleared() {
        previewPlayer?.stop()
        super.onCleared()
    }
}
