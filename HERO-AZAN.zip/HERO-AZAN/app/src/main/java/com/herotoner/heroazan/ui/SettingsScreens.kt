package com.herotoner.heroazan.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.herotoner.heroazan.BuildConfig
import com.herotoner.heroazan.alarms.Notifications
import com.herotoner.heroazan.model.AdhanChoice
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.CalcMethodOption
import com.herotoner.heroazan.model.MadhabOption
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.model.PrayerOffsets
import com.herotoner.heroazan.model.ThemeMode
import kotlin.math.roundToInt

@Composable
private fun NavRow(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
    }
}

@Composable
fun SettingsScreen(
    vm: AppViewModel,
    settings: AppSettings,
    onBack: () -> Unit,
    onOpenLocation: () -> Unit,
    onOpenCalc: () -> Unit,
    onOpenAdhan: () -> Unit,
    onOpenReminders: () -> Unit,
    onOpenPrivacy: () -> Unit,
) {
    val context = LocalContext.current
    var showAbout by remember { mutableStateOf(false) }

    Scaffold(topBar = { HeroTopBar("الإعدادات", onBack = onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionCard(title = "المواقيت") {
                NavRow("الموقع", settings.location?.displayName ?: "غير محدد", onOpenLocation)
                GoldDivider()
                NavRow("طريقة الحساب والمذهب والفروق", "${settings.calc.method.arabic} • ${settings.calc.madhab.arabic}", onOpenCalc)
                GoldDivider()
                LabeledRow("نظام 24 ساعة") { Switch(checked = settings.use24h, onCheckedChange = { vm.setUse24h(it) }) }
                GoldDivider()
                LabeledRow("تعديل التاريخ الهجري") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { vm.setHijriAdjust(settings.hijriAdjust - 1) }) { Text("−") }
                        Text(if (settings.hijriAdjust > 0) "+${settings.hijriAdjust}" else "${settings.hijriAdjust}")
                        TextButton(onClick = { vm.setHijriAdjust(settings.hijriAdjust + 1) }) { Text("+") }
                    }
                }
            }

            SectionCard(title = "الأذان والإشعارات") {
                NavRow("إعدادات الأذان لكل صلاة", "اختيار الصوت، أذان كامل أو تنبيه قصير، مستوى الصوت، اختبار", onOpenAdhan)
                GoldDivider()
                NavRow("التذكيرات", "أذكار الصباح والمساء، قراءة القرآن، تذكير شخصي", onOpenReminders)
                GoldDivider()
                PermissionsBlock(vm)
            }

            SectionCard(title = "المظهر") {
                Text("الوضع", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to "حسب النظام", ThemeMode.LIGHT to "نهاري", ThemeMode.DARK to "ليلي").forEach { (mode, label) ->
                        FilterChip(selected = settings.themeMode == mode, onClick = { vm.setTheme(mode) }, label = { Text(label) })
                    }
                }
                Text("حجم الخط: ${(settings.fontScale * 100).roundToInt()}%", style = MaterialTheme.typography.titleSmall)
                Slider(value = settings.fontScale, onValueChange = { vm.setFontScale((it * 20).roundToInt() / 20f) }, valueRange = 0.8f..1.6f)
            }

            SectionCard(title = "حول") {
                NavRow("معلومات التطبيق") { showAbout = true }
                GoldDivider()
                NavRow("سياسة الخصوصية", onClick = onOpenPrivacy)
            }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("HERO AZAN") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الإصدار ${BuildConfig.VERSION_NAME}")
                    Text("المطوّر: Hero Toner")
                    Text("مواقيت الصلاة تُحسب بمكتبة Adhan (Batoul Apps) حسب إحداثيات موقعك. نص القرآن الكريم بالرسم العثماني من مشروع «الموسوعة القرآنية» عبر الحزمة المفتوحة all-quran. الأذكار من «حصن المسلم». الخطوط: Cairo وAmiri Quran (رخصة OFL). إحداثيات المدن السورية: Wikidata (CC0).")
                    Text("لا يتطلب التطبيق تسجيل دخول ولا يحتوي إعلانات أو اشتراكات.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("حسناً") } },
        )
    }
}

@Composable
private fun PermissionsBlock(vm: AppViewModel) {
    val context = LocalContext.current
    val tick by vm.resumeTick.collectAsState()
    var refresh by remember { mutableStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    // tick / refresh force a re-check after returning from system settings or a permission dialog.
    val notificationsOk = remember(tick, refresh) { Notifications.areEnabled(context) }
    val exactOk = remember(tick, refresh) { vm.canScheduleExact() }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("الصلاحيات المطلوبة لتشغيل الأذان في وقته", style = MaterialTheme.typography.titleSmall)
        PermissionLine("الإشعارات", notificationsOk) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            openAppNotificationSettings(context)
        }
        PermissionLine("التنبيهات والمنبهات الدقيقة", exactOk) { openExactAlarmSettings(context) }
        PermissionLine("استثناء من توفير البطارية (موصى به)", null) { openBatterySettings(context) }
        Text(
            "إن منع النظام أي صلاحية فقد يتأخر الأذان أو لا يعمل، ولن يعدك التطبيق بما لا يستطيع ضمانه.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun PermissionLine(label: String, granted: Boolean?, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            when (granted) {
                true -> Text("ممنوحة ✓", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                false -> Text("غير ممنوحة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                null -> Text("لا يمكن التحقق منها تلقائياً", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (granted != true) TextButton(onClick = onFix) { Text("فتح") }
    }
}

// ----------------------------------------------------------------------------------------------

@Composable
fun CalcSettingsScreen(vm: AppViewModel, settings: AppSettings, onBack: () -> Unit) {
    Scaffold(topBar = { HeroTopBar("طريقة الحساب", onBack = onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            InfoBanner(
                "تختلف الطرق في زاوية الشمس تحت الأفق لحساب الفجر والعشاء، لذلك تختلف أوقات الفجر والعشاء بين دقائق قليلة. " +
                    "اختر الطريقة المعتمدة في بلدك، وقارن النتيجة بتقويم الأوقاف المحلي ثم اضبط الفروق يدوياً.",
            )
            SectionCard(title = "طريقة الحساب") {
                CalcMethodOption.entries.forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setMethod(m.id) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = settings.methodId == m.id, onClick = { vm.setMethod(m.id) })
                        Column(Modifier.weight(1f)) {
                            Text(m.arabic, style = MaterialTheme.typography.bodyLarge)
                            Text(m.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            SectionCard(title = "وقت العصر (المذهب)") {
                MadhabOption.entries.forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setMadhab(m.id) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = settings.madhabId == m.id, onClick = { vm.setMadhab(m.id) })
                        Column(Modifier.weight(1f)) {
                            Text(m.arabic, style = MaterialTheme.typography.bodyLarge)
                            Text(m.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            SectionCard(title = "فروق الدقائق (يدوياً)") {
                Text("تُضاف إلى الوقت المحسوب (من −${PrayerOffsets.MAX_MINUTES} إلى +${PrayerOffsets.MAX_MINUTES} دقيقة).", style = MaterialTheme.typography.bodySmall)
                listOf("fajr" to "الفجر", "sunrise" to "الشروق", "dhuhr" to "الظهر", "asr" to "العصر", "maghrib" to "المغرب", "isha" to "العشاء")
                    .forEach { (key, label) ->
                        val v = settings.offsets.of(key)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { vm.setOffset(key, v - 1) }) { Text("−") }
                            Text(
                                (if (v > 0) "+$v" else "$v") + " د",
                                modifier = Modifier.padding(horizontal = 12.dp),
                                style = MaterialTheme.typography.titleMedium,
                            )
                            OutlinedButton(onClick = { vm.setOffset(key, v + 1) }) { Text("+") }
                        }
                    }
                TextButton(onClick = { vm.resetOffsets() }) { Text("تصفير جميع الفروق") }
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdhanSettingsScreen(vm: AppViewModel, settings: AppSettings, onBack: () -> Unit) {
    val context = LocalContext.current
    val previewing by vm.previewing.collectAsState()
    val fallback by vm.lastPreviewFallback.collectAsState()
    var pickForPrayer by remember { mutableStateOf<Prayer?>(null) } // null + pickAll=false => none
    var pickAll by remember { mutableStateOf(false) }
    var chooserFor by remember { mutableStateOf<Prayer?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            vm.persistCustomAudio(uri)
            val choice = AdhanChoice(AdhanChoice.Type.CUSTOM, uri.toString())
            if (pickAll) vm.setAdhanChoiceForAll(choice) else pickForPrayer?.let { vm.setAdhanChoice(it, choice) }
        }
        pickForPrayer = null
        pickAll = false
    }

    Scaffold(topBar = { HeroTopBar("إعدادات الأذان", onBack = onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val library = remember { vm.availableAdhans() }
            if (library.isEmpty()) {
                InfoBanner(
                    "لا توجد ملفات أذان مضمّنة في التطبيق (يجب التأكد من ترخيص كل تسجيل قبل إضافته). " +
                        "اختر ملف أذان من هاتفك بالضغط على «اختيار ملف صوتي»، أو أضف ملفاً إلى المشروع كما في README.",
                    warning = true,
                )
            }

            SectionCard(title = "مستوى صوت الأذان") {
                Text("${(settings.adhanVolume * 100).roundToInt()}%  (نسبةً إلى مستوى صوت المنبّه في هاتفك)", style = MaterialTheme.typography.bodyMedium)
                Slider(value = settings.adhanVolume, onValueChange = { vm.setVolume((it * 20).roundToInt() / 20f) })
                Text(
                    "يمكن للتطبيق خفض الصوت فقط، أما رفعه فمن أزرار الصوت في الهاتف (صوت المنبّه) لأن التطبيق لا يتجاوز إعدادات النظام.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionCard(title = "اختبار") {
                Text("يشغّل الأذان بنفس الآلية التي تعمل وقت الصلاة (خدمة في المقدمة مع إشعار).", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.testAdhanService(Prayer.DHUHR) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp)); Text("اختبار صوت الأذان")
                    }
                    OutlinedButton(onClick = { vm.stopAdhanService() }) {
                        Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp)); Text("إيقاف")
                    }
                }
                if (!Notifications.areEnabled(context)) {
                    InfoBanner("الإشعارات معطّلة، قد لا يظهر إشعار الأذان.", warning = true)
                }
            }

            SectionCard(title = "تطبيق على كل الصلوات") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AlertMode.entries.forEach { mode ->
                        OutlinedButton(onClick = { vm.setAllAlertModes(mode) }) { Text(mode.arabic) }
                    }
                }
                OutlinedButton(onClick = { pickAll = true; filePicker.launch(arrayOf("audio/*")) }) {
                    Text("اختيار ملف صوتي لكل الصلوات")
                }
            }

            Prayer.entries.forEach { p ->
                val mode = settings.alertModeOf(p)
                val choice = settings.adhanChoiceOf(p)
                SectionCard(title = "صلاة ${p.arabic}") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AlertMode.entries.forEach { m ->
                            FilterChip(selected = mode == m, onClick = { vm.setAlertMode(p, m) }, label = { Text(m.arabic) })
                        }
                    }
                    if (mode == AlertMode.ADHAN_FULL) {
                        val name = when (choice.type) {
                            AdhanChoice.Type.DEFAULT -> library.firstOrNull()?.name ?: "افتراضي (لا يوجد ملف: نغمة تنبيه)"
                            AdhanChoice.Type.ASSET -> library.firstOrNull { it.id == choice.value }?.name ?: "غير متوفر"
                            AdhanChoice.Type.CUSTOM -> "ملف من هاتفك"
                        }
                        Text("الصوت: $name", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { chooserFor = p }) { Text("اختيار الصوت") }
                            val key = "p:${p.key}"
                            if (previewing == key) {
                                IconButton(onClick = { vm.stopPreview() }) { Icon(Icons.Filled.Stop, contentDescription = "إيقاف المعاينة") }
                            } else {
                                IconButton(onClick = { vm.previewAdhan(key, choice, settings.adhanVolume) }) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = "معاينة")
                                }
                            }
                        }
                    }
                }
            }
            if (fallback) {
                InfoBanner("المعاينة الأخيرة استخدمت نغمة افتراضية لأنه لا يوجد ملف أذان صالح للمصدر المختار.", warning = true)
            }
        }
    }

    chooserFor?.let { p ->
        val library = vm.availableAdhans()
        AlertDialog(
            onDismissRequest = { chooserFor = null },
            title = { Text("صوت أذان ${p.arabic}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    library.forEach { a ->
                        Row(Modifier.fillMaxWidth().clickable {
                            vm.setAdhanChoice(p, AdhanChoice(AdhanChoice.Type.ASSET, a.id)); chooserFor = null
                        }.padding(vertical = 8.dp)) {
                            Column {
                                Text(a.name, style = MaterialTheme.typography.bodyLarge)
                                if (a.source.isNotBlank()) Text("المصدر: ${a.source} • ${a.license}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (library.isEmpty()) Text("لا توجد ملفات مضمّنة.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = { pickForPrayer = p; pickAll = false; chooserFor = null; filePicker.launch(arrayOf("audio/*")) }) {
                        Text("اختيار ملف صوتي من الهاتف")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { chooserFor = null }) { Text("إغلاق") } },
        )
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Scaffold(topBar = { HeroTopBar("سياسة الخصوصية", onBack = onBack) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(ScreenPadding),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            listOf(
                "لا يتطلب HERO AZAN تسجيل دخول ولا ينشئ حساباً.",
                "الموقع: يُستخدم فقط لحساب مواقيت الصلاة واتجاه القبلة. يُطلب إذن الموقع فقط عند ضغطك على «استخدام GPS»، ويمكنك بدلاً من ذلك اختيار مدينتك يدوياً دون أي إذن. الموقع يُحفظ على جهازك ولا يُرسل إلى أي خادم.",
                "لا يجمع التطبيق أي معلومات شخصية، ولا يحتوي على أدوات تحليل أو تتبع أو إعلانات أو اشتراكات مدفوعة.",
                "البيانات المحفوظة على جهازك فقط: الموقع، إعدادات الحساب والأذان، الآيات المفضلة، آخر موضع قراءة، تقدّم الأذكار، التذكيرات.",
                "الاتصال بالإنترنت غير مطلوب لعمل التطبيق، وجميع الوظائف الأساسية تعمل دونه.",
                "الصلاحيات: الموقع (اختياري)، الإشعارات، التنبيهات الدقيقة، خدمة تشغيل الأذان في المقدمة، التشغيل بعد إعادة تشغيل الهاتف (لإعادة جدولة الأذان).",
                "ملفات الصوت التي تختارها من هاتفك لا تُنسخ ولا تُرسل؛ يحتفظ التطبيق بإذن قراءتها فقط.",
            ).forEach { Text(it, style = MaterialTheme.typography.bodyLarge) }
        }
    }
}
