package com.herotoner.heroazan.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.herotoner.heroazan.model.AdhanChoice
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.LocationSource
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.model.PrayerOffsets
import com.herotoner.heroazan.model.ThemeMode
import com.herotoner.heroazan.model.UserLocation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "hero_azan_settings")

/** All user preferences (location, calculation, adhan, appearance) stored with DataStore. */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val locId = stringPreferencesKey("loc_id")
        val locGov = stringPreferencesKey("loc_gov")
        val locCity = stringPreferencesKey("loc_city")
        val locArea = stringPreferencesKey("loc_area")
        val locLat = doublePreferencesKey("loc_lat")
        val locLon = doublePreferencesKey("loc_lon")
        val locZone = stringPreferencesKey("loc_zone")
        val locSource = stringPreferencesKey("loc_source")

        val method = stringPreferencesKey("calc_method")
        val madhab = stringPreferencesKey("calc_madhab")
        val volume = floatPreferencesKey("adhan_volume")
        val theme = stringPreferencesKey("theme_mode")
        val fontScale = floatPreferencesKey("font_scale")
        val quranFont = intPreferencesKey("quran_font_size")
        val use24h = booleanPreferencesKey("use_24h")
        val hijriAdjust = intPreferencesKey("hijri_adjust")
        val lastSurah = intPreferencesKey("last_surah")
        val lastAyah = intPreferencesKey("last_ayah")

        fun offset(key: String) = intPreferencesKey("offset_$key")
        fun alert(p: Prayer) = stringPreferencesKey("alert_${p.key}")
        fun adhan(p: Prayer) = stringPreferencesKey("adhan_${p.key}")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    private fun Preferences.toSettings(): AppSettings {
        val lat = this[Keys.locLat]
        val lon = this[Keys.locLon]
        val city = this[Keys.locCity]
        val location = if (lat != null && lon != null && city != null) {
            UserLocation(
                id = this[Keys.locId] ?: "saved",
                govAr = this[Keys.locGov],
                cityAr = city,
                areaAr = this[Keys.locArea],
                latitude = lat,
                longitude = lon,
                zoneId = this[Keys.locZone],
                source = runCatching { LocationSource.valueOf(this[Keys.locSource] ?: "") }
                    .getOrDefault(LocationSource.MANUAL),
            )
        } else null
        val defaults = AppSettings()
        return AppSettings(
            location = location,
            methodId = this[Keys.method] ?: defaults.methodId,
            madhabId = this[Keys.madhab] ?: defaults.madhabId,
            offsets = PrayerOffsets(
                fajr = this[Keys.offset("fajr")] ?: 0,
                sunrise = this[Keys.offset("sunrise")] ?: 0,
                dhuhr = this[Keys.offset("dhuhr")] ?: 0,
                asr = this[Keys.offset("asr")] ?: 0,
                maghrib = this[Keys.offset("maghrib")] ?: 0,
                isha = this[Keys.offset("isha")] ?: 0,
            ),
            alertModes = Prayer.entries.associateWith { AlertMode.fromName(this[Keys.alert(it)]) },
            adhanChoices = Prayer.entries.associateWith { AdhanChoice.decode(this[Keys.adhan(it)]) },
            adhanVolume = (this[Keys.volume] ?: defaults.adhanVolume).coerceIn(0f, 1f),
            themeMode = runCatching { ThemeMode.valueOf(this[Keys.theme] ?: "") }.getOrDefault(ThemeMode.SYSTEM),
            fontScale = (this[Keys.fontScale] ?: defaults.fontScale).coerceIn(0.8f, 1.6f),
            quranFontSize = (this[Keys.quranFont] ?: defaults.quranFontSize).coerceIn(18, 48),
            use24h = this[Keys.use24h] ?: defaults.use24h,
            hijriAdjust = (this[Keys.hijriAdjust] ?: 0).coerceIn(-2, 2),
            lastSurah = this[Keys.lastSurah] ?: 1,
            lastAyah = this[Keys.lastAyah] ?: 1,
        )
    }

    suspend fun setLocation(location: UserLocation) {
        context.settingsDataStore.edit { p ->
            p[Keys.locId] = location.id
            if (location.govAr != null) p[Keys.locGov] = location.govAr else p.remove(Keys.locGov)
            p[Keys.locCity] = location.cityAr
            if (location.areaAr != null) p[Keys.locArea] = location.areaAr else p.remove(Keys.locArea)
            p[Keys.locLat] = location.latitude
            p[Keys.locLon] = location.longitude
            if (location.zoneId != null) p[Keys.locZone] = location.zoneId else p.remove(Keys.locZone)
            p[Keys.locSource] = location.source.name
        }
    }

    suspend fun setMethod(id: String) = context.settingsDataStore.edit { it[Keys.method] = id }
    suspend fun setMadhab(id: String) = context.settingsDataStore.edit { it[Keys.madhab] = id }

    suspend fun setOffset(key: String, minutes: Int) {
        context.settingsDataStore.edit {
            it[Keys.offset(key)] = minutes.coerceIn(-PrayerOffsets.MAX_MINUTES, PrayerOffsets.MAX_MINUTES)
        }
    }

    suspend fun resetOffsets() {
        context.settingsDataStore.edit { p ->
            listOf("fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha").forEach { p.remove(Keys.offset(it)) }
        }
    }

    suspend fun setAlertMode(prayer: Prayer, mode: AlertMode) =
        context.settingsDataStore.edit { it[Keys.alert(prayer)] = mode.name }

    suspend fun setAllAlertModes(mode: AlertMode) {
        context.settingsDataStore.edit { p -> Prayer.entries.forEach { p[Keys.alert(it)] = mode.name } }
    }

    suspend fun setAdhanChoice(prayer: Prayer, choice: AdhanChoice) =
        context.settingsDataStore.edit { it[Keys.adhan(prayer)] = choice.encode() }

    suspend fun setAdhanChoiceForAll(choice: AdhanChoice) {
        context.settingsDataStore.edit { p -> Prayer.entries.forEach { p[Keys.adhan(it)] = choice.encode() } }
    }

    suspend fun setVolume(v: Float) = context.settingsDataStore.edit { it[Keys.volume] = v.coerceIn(0f, 1f) }
    suspend fun setTheme(mode: ThemeMode) = context.settingsDataStore.edit { it[Keys.theme] = mode.name }
    suspend fun setFontScale(v: Float) = context.settingsDataStore.edit { it[Keys.fontScale] = v.coerceIn(0.8f, 1.6f) }
    suspend fun setQuranFontSize(v: Int) = context.settingsDataStore.edit { it[Keys.quranFont] = v.coerceIn(18, 48) }
    suspend fun setUse24h(v: Boolean) = context.settingsDataStore.edit { it[Keys.use24h] = v }
    suspend fun setHijriAdjust(v: Int) = context.settingsDataStore.edit { it[Keys.hijriAdjust] = v.coerceIn(-2, 2) }

    suspend fun setLastRead(surah: Int, ayah: Int) {
        context.settingsDataStore.edit {
            it[Keys.lastSurah] = surah
            it[Keys.lastAyah] = ayah
        }
    }
}
