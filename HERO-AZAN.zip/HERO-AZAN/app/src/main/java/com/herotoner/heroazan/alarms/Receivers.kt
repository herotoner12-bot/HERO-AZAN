package com.herotoner.heroazan.alarms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.Prayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant

/** Runs [block] off the main thread while keeping the receiver alive (goAsync). */
private fun BroadcastReceiver.async(block: suspend () -> Unit) {
    val pending = goAsync()
    CoroutineScope(Dispatchers.Default).launch {
        try {
            block()
        } finally {
            pending.finish()
        }
    }
}

/** Fires at a prayer time. */
class AdhanAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.heroApp
        val prayer = Prayer.fromKey(intent.getStringExtra(AlarmScheduler.EXTRA_PRAYER)) ?: return
        val scheduledAt = Instant.ofEpochMilli(intent.getLongExtra(AlarmScheduler.EXTRA_SCHEDULED_AT, 0L))
        async {
            val now = Instant.now()
            val s = app.settings.current()
            // If the phone was off / the alarm is very late, do not play an old adhan.
            val tooLate = scheduledAt.toEpochMilli() > 0 && Duration.between(scheduledAt, now) > MAX_DELAY
            if (!tooLate) {
                when (s.alertModeOf(prayer)) {
                    AlertMode.ADHAN_FULL ->
                        runCatching { ContextCompat.startForegroundService(context, AdhanService.intent(context, prayer)) }
                            .onFailure {
                                // Foreground start refused by the system: still alert the user.
                                Notifications.postPrayerNotification(context, prayer, silent = false,
                                    note = "تعذّر تشغيل الأذان تلقائياً. افتح التطبيق للتحقق من الصلاحيات.")
                            }
                    AlertMode.SHORT_ALERT -> Notifications.postPrayerNotification(context, prayer, silent = false)
                    AlertMode.SILENT -> Notifications.postPrayerNotification(context, prayer, silent = true)
                    AlertMode.OFF -> Unit
                }
            }
            // +30 s guarantees the next call picks the following occurrence, never this one again.
            app.scheduler.rescheduleAll(now.plusSeconds(30))
        }
    }

    companion object {
        private val MAX_DELAY: Duration = Duration.ofMinutes(10)
    }
}

/** Fires for a user reminder. */
class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.heroApp
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_REMINDER_ID, -1)
        if (id < 0) return
        async {
            val r = app.database.reminders().getAll().firstOrNull { it.id == id }
            if (r != null && r.enabled) {
                val kind = ReminderKind.fromName(r.kind)
                Notifications.postReminder(context, r.id, r.title, r.body, kind.destination)
            }
            app.scheduler.rescheduleAll(Instant.now().plusSeconds(30))
        }
    }
}

/** Boot / app update / date / time / time-zone change / exact-alarm permission change. */
class RescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.heroApp
        async { app.scheduler.rescheduleAll() }
    }
}
