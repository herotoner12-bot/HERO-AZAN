package com.herotoner.heroazan.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorite_locations")
data class FavoriteLocationEntity(
    @PrimaryKey val id: String,
    val govAr: String?,
    val cityAr: String,
    val areaAr: String?,
    val latitude: Double,
    val longitude: Double,
    val zoneId: String?,
    val source: String,
    val createdAt: Long,
)

@Entity(tableName = "favorite_ayahs", primaryKeys = ["surah", "ayah"])
data class FavoriteAyahEntity(
    val surah: Int,
    val ayah: Int,
    val createdAt: Long,
)

/** Counter progress of one dhikr; [dayKey] (epoch day) makes progress reset every day. */
@Entity(tableName = "adhkar_progress", primaryKeys = ["sectionId", "itemIndex"])
data class AdhkarProgressEntity(
    val sectionId: String,
    val itemIndex: Int,
    val count: Int,
    val dayKey: Long,
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    /** ReminderKind name */
    val kind: String,
    val title: String,
    val body: String,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean,
    /** only for PRAYER_BEFORE */
    val prayerKey: String?,
    /** only for PRAYER_BEFORE */
    val minutesBefore: Int,
)

@Dao
interface FavoriteLocationDao {
    @Query("SELECT * FROM favorite_locations ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<FavoriteLocationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FavoriteLocationEntity)

    @Query("DELETE FROM favorite_locations WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface FavoriteAyahDao {
    @Query("SELECT * FROM favorite_ayahs ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<FavoriteAyahEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FavoriteAyahEntity)

    @Query("DELETE FROM favorite_ayahs WHERE surah = :surah AND ayah = :ayah")
    suspend fun delete(surah: Int, ayah: Int)
}

@Dao
interface AdhkarProgressDao {
    @Query("SELECT * FROM adhkar_progress WHERE sectionId = :sectionId")
    fun observeSection(sectionId: String): Flow<List<AdhkarProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AdhkarProgressEntity)

    @Query("DELETE FROM adhkar_progress WHERE sectionId = :sectionId")
    suspend fun clearSection(sectionId: String)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY hour, minute, id")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders")
    suspend fun getAll(): List<ReminderEntity>

    @Query("SELECT COUNT(*) FROM reminders")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ReminderEntity): Long

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun delete(id: Int)
}

@Database(
    entities = [
        FavoriteLocationEntity::class,
        FavoriteAyahEntity::class,
        AdhkarProgressEntity::class,
        ReminderEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteLocations(): FavoriteLocationDao
    abstract fun favoriteAyahs(): FavoriteAyahDao
    abstract fun adhkarProgress(): AdhkarProgressDao
    abstract fun reminders(): ReminderDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "hero_azan.db").build()
    }
}
