package com.herotoner.heroazan.alarms

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.herotoner.heroazan.heroApp
import java.util.concurrent.TimeUnit

/** Periodic safety net that re-programs all alarms (in case the OS dropped any). */
class RescheduleWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        applicationContext.heroApp.scheduler.rescheduleAll()
        return Result.success()
    }

    companion object {
        private const val NAME = "hero_azan_reschedule"

        fun enqueuePeriodic(context: Context) {
            val request = PeriodicWorkRequestBuilder<RescheduleWorker>(12, TimeUnit.HOURS).build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
