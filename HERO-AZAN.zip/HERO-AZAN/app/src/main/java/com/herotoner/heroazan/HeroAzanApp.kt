package com.herotoner.heroazan

import android.app.Application
import com.herotoner.heroazan.alarms.AdhanLibrary
import com.herotoner.heroazan.alarms.AlarmScheduler
import com.herotoner.heroazan.alarms.Notifications
import com.herotoner.heroazan.alarms.RescheduleWorker
import com.herotoner.heroazan.data.AdhkarRepository
import com.herotoner.heroazan.data.AppDatabase
import com.herotoner.heroazan.data.GpsLocationProvider
import com.herotoner.heroazan.data.LocationsRepository
import com.herotoner.heroazan.data.QuranRepository
import com.herotoner.heroazan.data.SettingsRepository

/** Simple manual dependency container (no DI framework needed for an app this size). */
class HeroAzanApp : Application() {

    val settings by lazy { SettingsRepository(this) }
    val database by lazy { AppDatabase.build(this) }
    val locations by lazy { LocationsRepository(this) }
    val quran by lazy { QuranRepository(this) }
    val adhkar by lazy { AdhkarRepository(this) }
    val adhanLibrary by lazy { AdhanLibrary(this) }
    val gps by lazy { GpsLocationProvider(this) }
    val scheduler by lazy { AlarmScheduler(this, settings, database.reminders()) }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        // Safety net: even if the system drops an alarm, this re-programs everything twice a day.
        RescheduleWorker.enqueuePeriodic(this)
    }
}

val android.content.Context.heroApp: HeroAzanApp
    get() = applicationContext as HeroAzanApp
