package com.herotoner.heroazan.domain

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.util.Locale

/** Arabic date/time formatting with Latin digits, independent of the device locale. */
object ArabicFormats {

    // Levantine (Syrian) names of the Gregorian months
    private val gregorianMonths = arrayOf(
        "كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران",
        "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول",
    )

    private val hijriMonths = arrayOf(
        "محرّم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
    )

    private fun dayName(d: DayOfWeek): String = when (d) {
        DayOfWeek.MONDAY -> "الاثنين"
        DayOfWeek.TUESDAY -> "الثلاثاء"
        DayOfWeek.WEDNESDAY -> "الأربعاء"
        DayOfWeek.THURSDAY -> "الخميس"
        DayOfWeek.FRIDAY -> "الجمعة"
        DayOfWeek.SATURDAY -> "السبت"
        DayOfWeek.SUNDAY -> "الأحد"
    }

    fun gregorian(date: LocalDate): String =
        "${dayName(date.dayOfWeek)}، ${date.dayOfMonth} ${gregorianMonths[date.monthValue - 1]} ${date.year}"

    /**
     * Hijri date from the Umm al-Qura calendar. Local moon-sighting can differ by a
     * day, so the user can shift it with [adjustDays] (-2..+2).
     */
    fun hijri(date: LocalDate, adjustDays: Int = 0): String {
        val h = HijrahDate.from(date.plusDays(adjustDays.toLong()))
        val day = h.get(ChronoField.DAY_OF_MONTH)
        val month = h.get(ChronoField.MONTH_OF_YEAR)
        val year = h.get(ChronoField.YEAR)
        return "$day ${hijriMonths[month - 1]} $year هـ"
    }

    /** "5:07 ص" or "05:07". */
    fun clock(instant: Instant, zone: ZoneId, use24h: Boolean): String {
        val t = instant.atZone(zone)
        val h = t.hour
        val m = t.minute
        return if (use24h) {
            String.format(Locale.US, "%02d:%02d", h, m)
        } else {
            val h12 = if (h % 12 == 0) 12 else h % 12
            String.format(Locale.US, "%d:%02d %s", h12, m, if (h < 12) "ص" else "م")
        }
    }

    /** Remaining time as HH:MM:SS. */
    fun countdown(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    /** Short human wording: "بعد 3 ساعات و12 دقيقة". */
    fun remainingWords(totalSeconds: Long): String {
        val minutesTotal = (totalSeconds.coerceAtLeast(0) + 59) / 60
        val h = minutesTotal / 60
        val m = minutesTotal % 60
        return when {
            h == 0L -> "$m دقيقة"
            m == 0L -> "$h ساعة"
            else -> "$h ساعة و$m دقيقة"
        }
    }
}
