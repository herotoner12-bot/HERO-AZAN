package com.herotoner.heroazan.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.herotoner.heroazan.alarms.Notifications
import com.herotoner.heroazan.alarms.ReminderKind
import com.herotoner.heroazan.data.ReminderEntity
import com.herotoner.heroazan.model.Prayer
import java.util.Locale

private fun timeLabel(r: ReminderEntity): String =
    if (ReminderKind.fromName(r.kind) == ReminderKind.PRAYER_BEFORE) {
        val p = Prayer.fromKey(r.prayerKey)?.arabic ?: ""
        "قبل صلاة $p بـ ${r.minutesBefore} دقيقة"
    } else {
        val h12 = if (r.hour % 12 == 0) 12 else r.hour % 12
        String.format(Locale.US, "%d:%02d %s", h12, r.minute, if (r.hour < 12) "ص" else "م") + " • يومياً"
    }

@Composable
fun RemindersScreen(vm: AppViewModel, onBack: () -> Unit) {
    val reminders by vm.reminders.collectAsState()
    val context = LocalContext.current
    var editing by remember { mutableStateOf<ReminderEntity?>(null) }

    Scaffold(
        topBar = { HeroTopBar("التذكيرات", onBack = onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editing = ReminderEntity(kind = ReminderKind.CUSTOM.name, title = "", body = "", hour = 9, minute = 0,
                        enabled = true, prayerKey = null, minutesBefore = 15)
                },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("تذكير جديد") },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = ListContentPadding,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "info") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoBanner("التذكيرات محلية بالكامل وتعمل دون إنترنت. كل تذكير يتكرر يومياً في الوقت المحدد.")
                    if (!Notifications.areEnabled(context)) {
                        InfoBanner("الإشعارات معطّلة للتطبيق، لن تظهر التذكيرات.", warning = true)
                        TextButton(onClick = { openAppNotificationSettings(context) }) { Text("فتح إعدادات الإشعارات") }
                    }
                    if (!vm.canScheduleExact()) {
                        InfoBanner("صلاحية التنبيه الدقيق غير ممنوحة، قد تتأخر التذكيرات بضع دقائق.", warning = true)
                        TextButton(onClick = { openExactAlarmSettings(context) }) { Text("منح الصلاحية") }
                    }
                }
            }
            items(reminders, key = { "reminder-${it.id}" }) { r ->
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title.ifBlank { vm.reminderKindLabel(r.kind) }, style = MaterialTheme.typography.titleMedium)
                            Text(timeLabel(r), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                            if (r.body.isNotBlank()) {
                                Text(r.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(checked = r.enabled, onCheckedChange = { vm.saveReminder(r.copy(enabled = it)) })
                    }
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { editing = r }) { Icon(Icons.Filled.Edit, contentDescription = "تعديل") }
                        IconButton(onClick = { vm.deleteReminder(r.id) }) { Icon(Icons.Filled.Delete, contentDescription = "حذف") }
                    }
                }
            }
        }
    }

    editing?.let { r ->
        ReminderDialog(
            initial = r,
            onDismiss = { editing = null },
            onSave = { vm.saveReminder(it); editing = null },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ReminderDialog(initial: ReminderEntity, onDismiss: () -> Unit, onSave: (ReminderEntity) -> Unit) {
    var kind by remember { mutableStateOf(ReminderKind.fromName(initial.kind)) }
    var title by remember { mutableStateOf(initial.title) }
    var body by remember { mutableStateOf(initial.body) }
    var prayer by remember { mutableStateOf(Prayer.fromKey(initial.prayerKey) ?: Prayer.MAGHRIB) }
    var minutesBefore by remember { mutableIntStateOf(initial.minutesBefore.coerceIn(1, 120)) }
    val timeState = rememberTimePickerState(initialHour = initial.hour, initialMinute = initial.minute, is24Hour = false)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id == 0) "تذكير جديد" else "تعديل التذكير") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("النوع", style = MaterialTheme.typography.titleSmall)
                androidx.compose.foundation.layout.Column {
                    ReminderKind.entries.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { k ->
                                FilterChip(
                                    selected = kind == k,
                                    onClick = {
                                        kind = k
                                        if (title.isBlank() || ReminderKind.entries.any { it.arabic == title }) title = k.arabic
                                    },
                                    label = { Text(k.arabic) },
                                )
                            }
                        }
                    }
                }
                OutlinedTextField(title, { title = it }, label = { Text("العنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { body = it }, label = { Text("نص التذكير (اختياري)") }, modifier = Modifier.fillMaxWidth())
                if (kind == ReminderKind.PRAYER_BEFORE) {
                    Text("الصلاة", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Prayer.entries.forEach { p -> FilterChip(selected = prayer == p, onClick = { prayer = p }, label = { Text(p.arabic) }) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("قبل الصلاة بـ $minutesBefore دقيقة", modifier = Modifier.weight(1f))
                        TextButton(onClick = { minutesBefore = (minutesBefore - 5).coerceAtLeast(1) }) { Text("−5") }
                        TextButton(onClick = { minutesBefore = (minutesBefore + 5).coerceAtMost(120) }) { Text("+5") }
                    }
                } else {
                    Text("الوقت (يومياً)", style = MaterialTheme.typography.titleSmall)
                    TimePicker(state = timeState)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        kind = kind.name,
                        title = title.ifBlank { kind.arabic },
                        body = body,
                        hour = timeState.hour,
                        minute = timeState.minute,
                        enabled = true,
                        prayerKey = if (kind == ReminderKind.PRAYER_BEFORE) prayer.key else null,
                        minutesBefore = minutesBefore,
                    ),
                )
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
