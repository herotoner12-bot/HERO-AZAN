package com.herotoner.heroazan.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroazan.data.SurahInfo
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.ThemeMode
import com.herotoner.heroazan.ui.theme.Gold
import com.herotoner.heroazan.ui.theme.IslamicGreen
import com.herotoner.heroazan.ui.theme.QuranFamily
import com.herotoner.heroazan.ui.theme.isDarkTheme
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged

/** Arabic-Indic digits for ayah numbers shown inside the ornament. */
private fun arabicDigits(n: Int): String =
    n.toString().map { if (it in '0'..'9') ('٠' + (it - '0')) else it }.joinToString("")

private fun normSearch(s: String): String = s
    .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
    .replace(Regex("[أإآٱ]"), "ا")
    .replace('ة', 'ه').replace('ى', 'ي')
    .lowercase().trim()

@Composable
fun QuranListScreen(
    vm: AppViewModel,
    settings: AppSettings,
    onOpenSurah: (Int, Int) -> Unit,
    onOpenFavorites: () -> Unit,
) {
    val repo = LocalContext.current.heroApp.quran
    val surahs by produceState<List<SurahInfo>>(emptyList()) { value = repo.surahs() }
    var query by rememberSaveable { mutableStateOf("") }
    val q = normSearch(query)
    val shown = surahs.filter {
        q.isEmpty() || normSearch(it.ar).contains(q) || it.translit.lowercase().contains(q) || it.id.toString() == q
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = ScreenPadding, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("القرآن الكريم", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenFavorites) {
                Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp)); Text("المفضلة")
            }
        }
        LazyColumn(contentPadding = ListContentPadding, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item(key = "last-read") {
                val last = surahs.firstOrNull { it.id == settings.lastSurah }
                if (last != null) {
                    SectionCard(title = "متابعة القراءة") {
                        Text("سورة ${last.ar} • الآية ${settings.lastAyah}", style = MaterialTheme.typography.bodyLarge)
                        Button(onClick = { onOpenSurah(last.id, settings.lastAyah) }, modifier = Modifier.fillMaxWidth()) { Text("متابعة من آخر موضع") }
                    }
                }
            }
            item(key = "search") {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("ابحث باسم السورة أو رقمها") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                )
            }
            items(shown, key = { "surah-${it.id}" }) { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { onOpenSurah(s.id, 1) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(IslamicGreen), contentAlignment = Alignment.Center) {
                        Text(arabicDigits(s.id), color = Gold, style = MaterialTheme.typography.labelLarge)
                    }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.ar, fontFamily = QuranFamily, fontSize = 24.sp)
                        Text(
                            "${if (s.meccan) "مكية" else "مدنية"} • ${arabicDigits(s.ayahCount)} آية",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(FlowPreview::class)
@Composable
fun QuranReaderScreen(
    vm: AppViewModel,
    settings: AppSettings,
    surahId: Int,
    startAyah: Int,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val repo = context.heroApp.quran
    val clipboard = LocalClipboardManager.current
    val surahs by produceState<List<SurahInfo>>(emptyList()) { value = repo.surahs() }
    val verses by produceState<List<String>?>(null, surahId) { value = repo.verses(surahId) }
    val basmala by produceState("", surahId) { value = repo.basmala() }
    val favorites by vm.favoriteAyahs.collectAsState()
    val surah = surahs.firstOrNull { it.id == surahId }
    var selected by rememberSaveable(surahId) { mutableStateOf<Int?>(null) }

    val hasHeader = surahId != 9 && surahId != 1 // basmala line (Al-Fatiha carries it as ayah 1)
    val headerItems = 1 + if (hasHeader) 1 else 0
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (headerItems + (startAyah - 1)).coerceAtLeast(0),
    )

    LaunchedEffect(surahId) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .debounce(700)
            .distinctUntilChanged()
            .collect { idx ->
                val ayah = (idx - headerItems + 1).coerceAtLeast(1)
                vm.setLastRead(surahId, ayah)
            }
    }

    val dark = isDarkTheme()
    Scaffold(
        topBar = {
            HeroTopBar(
                title = surah?.let { "سورة ${it.ar}" } ?: "القرآن الكريم",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { vm.setQuranFontSize(settings.quranFontSize - 2) }) {
                        Icon(Icons.Filled.TextDecrease, contentDescription = "تصغير الخط")
                    }
                    IconButton(onClick = { vm.setQuranFontSize(settings.quranFontSize + 2) }) {
                        Icon(Icons.Filled.TextIncrease, contentDescription = "تكبير الخط")
                    }
                    IconButton(onClick = { vm.setTheme(if (dark) ThemeMode.LIGHT else ThemeMode.DARK) }) {
                        Icon(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, contentDescription = "الوضع الليلي")
                    }
                },
            )
        },
    ) { padding ->
        val list = verses
        if (list == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { Text("جارٍ التحميل…") }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = ListContentPadding,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                item(key = "header") {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(IslamicGreen).padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("سورة ${surah?.ar ?: ""}", fontFamily = QuranFamily, fontSize = 30.sp, color = Gold)
                        Text(
                            "${if (surah?.meccan == true) "مكية" else "مدنية"} • ${surah?.ayahCount ?: list.size} آية",
                            color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                if (hasHeader) {
                    item(key = "basmala") {
                        Text(
                            basmala, fontFamily = QuranFamily, fontSize = (settings.quranFontSize).sp,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                        )
                    }
                }
                items(list.size, key = { "ayah-$it" }) { i ->
                    val ayahNo = i + 1
                    val isFav = favorites.any { it.surah == surahId && it.ayah == ayahNo }
                    val isSelected = selected == ayahNo
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
                            .clickable { selected = if (isSelected) null else ayahNo }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                    ) {
                        Text(
                            list[i] + " ۝" + arabicDigits(ayahNo),
                            fontFamily = QuranFamily,
                            fontSize = settings.quranFontSize.sp,
                            lineHeight = (settings.quranFontSize * 1.9f).sp,
                            textAlign = TextAlign.Justify,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        if (isSelected) {
                            val shareString = "${list[i]} ﴿$ayahNo﴾\n[سورة ${surah?.ar ?: ""} - الآية $ayahNo]\nHERO AZAN"
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                IconButton(onClick = { vm.toggleFavoriteAyah(surahId, ayahNo, isFav) }) {
                                    Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = "مفضلة")
                                }
                                IconButton(onClick = { clipboard.setText(AnnotatedString(shareString)) }) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = "نسخ")
                                }
                                IconButton(onClick = { shareText(context, shareString) }) {
                                    Icon(Icons.Filled.Share, contentDescription = "مشاركة")
                                }
                                IconButton(onClick = { vm.setLastRead(surahId, ayahNo) }) {
                                    Icon(Icons.Filled.Bookmark, contentDescription = "حفظ كآخر موضع قراءة")
                                }
                            }
                        }
                    }
                }
                item(key = "end") { Spacer(Modifier.size(24.dp)) }
            }
        }
    }
}

@Composable
fun FavoriteAyahsScreen(vm: AppViewModel, onOpen: (Int, Int) -> Unit, onBack: () -> Unit) {
    val repo = LocalContext.current.heroApp.quran
    val favorites by vm.favoriteAyahs.collectAsState()
    val surahs by produceState<List<SurahInfo>>(emptyList()) { value = repo.surahs() }

    Scaffold(topBar = { HeroTopBar("الآيات المفضلة", onBack = onBack) }) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = ListContentPadding,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (favorites.isEmpty()) {
                item { Text("لم تضف آيات إلى المفضلة بعد. اضغط على أي آية في المصحف ثم على أيقونة القلب.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            items(favorites, key = { "${it.surah}:${it.ayah}" }) { f ->
                val text by produceState("", f.surah, f.ayah) { value = repo.verse(f.surah, f.ayah).orEmpty() }
                val name = surahs.firstOrNull { it.id == f.surah }?.ar ?: ""
                SectionCard(modifier = Modifier.clickable { onOpen(f.surah, f.ayah) }) {
                    Text(text, fontFamily = QuranFamily, fontSize = 24.sp, lineHeight = 44.sp, textAlign = TextAlign.Justify)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("سورة $name • الآية ${f.ayah}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.toggleFavoriteAyah(f.surah, f.ayah, true) }) {
                            Icon(Icons.Filled.Favorite, contentDescription = "إزالة من المفضلة")
                        }
                    }
                }
            }
        }
    }
}
