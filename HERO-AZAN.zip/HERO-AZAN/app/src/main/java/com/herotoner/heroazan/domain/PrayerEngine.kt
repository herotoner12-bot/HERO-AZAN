package com.herotoner.heroazan.domain

import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import com.herotoner.heroazan.model.DayPrayerTimes
import com.herotoner.heroazan.model.NextPrayer
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.model.PrayerCalcSettings
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Thin wrapper around the Adhan library. It is pure Kotlin/JVM (no Android classes)
 * so it can be unit-tested against an independent reference implementation.
 *
 * Time zones: Adhan returns absolute instants for a calendar date at a location,
 * so daylight-saving / time-zone changes only affect how those instants are
 * *displayed*, never the instants themselves.
 */
object PrayerEngine {

    fun compute(
        latitude: Double,
        longitude: Double,
        date: LocalDate,
        zone: ZoneId,
        calc: PrayerCalcSettings,
    ): DayPrayerTimes {
        val params = calc.method.method.parameters
        params.madhab = calc.madhab.madhab
        params.adjustments.fajr = calc.offsets.fajr
        params.adjustments.sunrise = calc.offsets.sunrise
        params.adjustments.dhuhr = calc.offsets.dhuhr
        params.adjustments.asr = calc.offsets.asr
        params.adjustments.maghrib = calc.offsets.maghrib
        params.adjustments.isha = calc.offsets.isha

        val times = PrayerTimes(
            Coordinates(latitude, longitude),
            DateComponents(date.year, date.monthValue, date.dayOfMonth),
            params,
        )
        // Adhan rounds to whole minutes but leaves a random millisecond part in the Date it returns;
        // truncate so every time is exactly hh:mm:00 (deterministic comparisons, alarms at :00 seconds).
        fun clean(d: java.util.Date?, name: String): Instant =
            requireNotNull(d) { "$name unavailable at this latitude" }.toInstant().truncatedTo(ChronoUnit.SECONDS)
        return DayPrayerTimes(
            date = date,
            zone = zone,
            fajr = clean(times.fajr, "fajr"),
            sunrise = clean(times.sunrise, "sunrise"),
            dhuhr = clean(times.dhuhr, "dhuhr"),
            asr = clean(times.asr, "asr"),
            maghrib = clean(times.maghrib, "maghrib"),
            isha = clean(times.isha, "isha"),
        )
    }

    /** First prayer strictly after [now] (tomorrow's Fajr once Isha has passed). */
    fun nextPrayer(
        now: Instant,
        latitude: Double,
        longitude: Double,
        zone: ZoneId,
        calc: PrayerCalcSettings,
    ): NextPrayer {
        val today = now.atZone(zone).toLocalDate()
        val t = compute(latitude, longitude, today, zone, calc)
        for (p in Prayer.entries) {
            if (t.timeOf(p) > now) return NextPrayer(p, t.timeOf(p), false)
        }
        val tomorrow = compute(latitude, longitude, today.plusDays(1), zone, calc)
        return NextPrayer(Prayer.FAJR, tomorrow.fajr, true)
    }

    /**
     * The prayer whose time is currently running. Between sunrise and Dhuhr no
     * prayer is "current" (returns null), and after Isha / before Fajr it is Isha.
     */
    fun currentPrayer(
        now: Instant,
        latitude: Double,
        longitude: Double,
        zone: ZoneId,
        calc: PrayerCalcSettings,
    ): Prayer? {
        val today = now.atZone(zone).toLocalDate()
        val t = compute(latitude, longitude, today, zone, calc)
        return when {
            now < t.fajr -> Prayer.ISHA
            now < t.sunrise -> Prayer.FAJR
            now < t.dhuhr -> null
            now < t.asr -> Prayer.DHUHR
            now < t.maghrib -> Prayer.ASR
            now < t.isha -> Prayer.MAGHRIB
            else -> Prayer.ISHA
        }
    }

    /** For each prayer, its next occurrence strictly after [now]; used to program alarms. */
    fun upcomingPerPrayer(
        now: Instant,
        latitude: Double,
        longitude: Double,
        zone: ZoneId,
        calc: PrayerCalcSettings,
    ): Map<Prayer, Instant> {
        val today = now.atZone(zone).toLocalDate()
        val days = (0..2).map { compute(latitude, longitude, today.plusDays(it.toLong()), zone, calc) }
        return Prayer.entries.associateWith { p ->
            days.map { it.timeOf(p) }.first { it > now }
        }
    }
}
