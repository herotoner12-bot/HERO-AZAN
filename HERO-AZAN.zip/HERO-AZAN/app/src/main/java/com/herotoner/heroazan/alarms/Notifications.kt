package com.herotoner.heroazan.alarms

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.herotoner.heroazan.MainActivity
import com.herotoner.heroazan.R
import com.herotoner.heroazan.model.Prayer

@SuppressLint("MissingPermission") // every notify() is guarded by areEnabled()
object Notifications {
    const val CH_ADHAN_PLAYBACK = "adhan_playback"
    const val CH_PRAYER_ALERT = "prayer_alert"
    const val CH_PRAYER_SILENT = "prayer_silent"
    const val CH_REMINDERS = "reminders"

    const val ID_ADHAN_PLAYBACK = 4001
    private const val ID_PRAYER_BASE = 4100
    private const val ID_REMINDER_BASE = 5000

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(
                CH_ADHAN_PLAYBACK,
                context.getString(R.string.channel_adhan_playback),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = context.getString(R.string.channel_adhan_playback_desc)
                setSound(null, null)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CH_PRAYER_ALERT,
                context.getString(R.string.channel_prayer_alert),
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = context.getString(R.string.channel_prayer_alert_desc)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                enableVibration(true)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CH_PRAYER_SILENT,
                context.getString(R.string.channel_prayer_silent),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = context.getString(R.string.channel_prayer_silent_desc)
                setSound(null, null)
                enableVibration(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CH_REMINDERS,
                context.getString(R.string.channel_reminders),
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply { description = context.getString(R.string.channel_reminders_desc) },
        )
    }

    fun hasPostPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun areEnabled(context: Context): Boolean = NotificationManagerCompat.from(context).areNotificationsEnabled()

    private fun openAppIntent(context: Context, destination: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (destination != null) putExtra(MainActivity.EXTRA_DESTINATION, destination)
        }
        return PendingIntent.getActivity(
            context,
            destination?.hashCode() ?: 0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    fun adhanPlaybackNotification(context: Context, prayer: Prayer, fallbackNote: String?): android.app.Notification {
        val stop = PendingIntent.getService(
            context,
            1,
            Intent(context, AdhanService::class.java).setAction(AdhanService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(context, CH_ADHAN_PLAYBACK)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("حان الآن وقت صلاة ${prayer.arabic}")
            .setContentText(fallbackNote ?: "اضغط «إيقاف» لإسكات الأذان")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent(context, "prayer"))
            .addAction(0, "إيقاف", stop)
            .build()
    }

    fun postPrayerNotification(context: Context, prayer: Prayer, silent: Boolean, note: String? = null) {
        if (!areEnabled(context)) return
        val n = NotificationCompat.Builder(context, if (silent) CH_PRAYER_SILENT else CH_PRAYER_ALERT)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("حان الآن وقت صلاة ${prayer.arabic}")
            .setContentText(note ?: "حيّ على الصلاة")
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (silent) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(context, "prayer"))
            .build()
        runCatching {
            NotificationManagerCompat.from(context).notify(ID_PRAYER_BASE + prayer.ordinal, n)
        }
    }

    fun postReminder(context: Context, reminderId: Int, title: String, body: String, destination: String?) {
        if (!areEnabled(context)) return
        val n = NotificationCompat.Builder(context, CH_REMINDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(context, destination))
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(ID_REMINDER_BASE + reminderId, n) }
    }
}
