package com.herotoner.heroazan.ui

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroazan.domain.QiblaCalculator
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.ui.theme.Gold
import com.herotoner.heroazan.ui.theme.IslamicGreen
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Live compass reading. [headingTrue] is degrees clockwise from TRUE north, or null if unknown. */
data class CompassState(
    val sensorAvailable: Boolean = true,
    val headingTrue: Float? = null,
    /** SensorManager.SENSOR_STATUS_* of the orientation sensor */
    val accuracy: Int = SensorManager.SENSOR_STATUS_UNRELIABLE,
    /** magnetic field magnitude in microtesla (Earth: ~25..65) */
    val fieldStrength: Float? = null,
) {
    val needsCalibration: Boolean
        get() = headingTrue != null && accuracy <= SensorManager.SENSOR_STATUS_ACCURACY_LOW
    val fieldAbnormal: Boolean
        get() = fieldStrength != null && (fieldStrength < 20f || fieldStrength > 70f)
}

/**
 * Registers the rotation-vector sensor (fuses magnetometer + accelerometer + gyroscope when the
 * device has them), with an accelerometer+magnetometer fallback. The magnetic heading is converted
 * to true north with GeomagneticField so it matches the great-circle Qibla bearing.
 */
@Composable
fun rememberCompass(latitude: Double, longitude: Double): State<CompassState> {
    val context = LocalContext.current
    val state = remember { mutableStateOf(CompassState()) }

    DisposableEffect(latitude, longitude) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        if (rotation == null && (accel == null || mag == null)) {
            state.value = CompassState(sensorAvailable = false)
            return@DisposableEffect onDispose { }
        }

        val declination = GeomagneticField(latitude.toFloat(), longitude.toFloat(), 0f, System.currentTimeMillis()).declination
        var sinSum = 0f
        var cosSum = 0f
        var first = true
        var accuracy = SensorManager.SENSOR_STATUS_UNRELIABLE
        var field: Float? = null
        val gravity = FloatArray(3)
        val geomagnetic = FloatArray(3)
        var haveGravity = false
        var haveMag = false
        val r = FloatArray(9)
        val remapped = FloatArray(9)
        val ori = FloatArray(3)

        fun publish(rot: FloatArray) {
            val upright = abs(rot[8]) < 0.6f
            val m = if (upright) {
                SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, remapped)
                remapped
            } else rot
            SensorManager.getOrientation(m, ori)
            val azimuthMagnetic = Math.toDegrees(ori[0].toDouble()).toFloat()
            val trueHeading = azimuthMagnetic + declination
            val rad = Math.toRadians(trueHeading.toDouble())
            val alpha = if (first) 1f else 0.15f // low-pass on the unit vector (no wrap-around glitch)
            sinSum = sinSum * (1 - alpha) + sin(rad).toFloat() * alpha
            cosSum = cosSum * (1 - alpha) + cos(rad).toFloat() * alpha
            first = false
            val smooth = ((Math.toDegrees(atan2(sinSum.toDouble(), cosSum.toDouble())) + 360.0) % 360.0).toFloat()
            state.value = CompassState(true, smooth, accuracy, field)
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when (event.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR -> {
                        SensorManager.getRotationMatrixFromVector(r, event.values)
                        publish(r)
                    }
                    Sensor.TYPE_ACCELEROMETER -> {
                        System.arraycopy(event.values, 0, gravity, 0, 3)
                        haveGravity = true
                        if (rotation == null && haveMag && SensorManager.getRotationMatrix(r, null, gravity, geomagnetic)) publish(r)
                    }
                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        System.arraycopy(event.values, 0, geomagnetic, 0, 3)
                        haveMag = true
                        val v = event.values
                        val magnitude = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
                        field = field?.let { it * 0.9f + magnitude * 0.1f } ?: magnitude
                        if (rotation == null) accuracy = event.accuracy
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor, acc: Int) {
                if (sensor.type == Sensor.TYPE_ROTATION_VECTOR || (rotation == null && sensor.type == Sensor.TYPE_MAGNETIC_FIELD)) {
                    accuracy = acc
                }
            }
        }

        if (rotation != null) sm.registerListener(listener, rotation, SensorManager.SENSOR_DELAY_GAME)
        else {
            sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
        }
        // The magnetometer is also used to detect a disturbed magnetic field.
        if (mag != null) sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_UI)

        onDispose { sm.unregisterListener(listener) }
    }
    return state
}

@Composable
fun QiblaScreen(settings: AppSettings, onOpenLocation: () -> Unit) {
    val loc = settings.location
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(ScreenPadding),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("اتجاه القبلة", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)

        if (loc == null) {
            InfoBanner("حدّد موقعك لحساب اتجاه القبلة. يعمل ذلك بالموقع المحفوظ دون إنترنت.", warning = true)
            Button(onClick = onOpenLocation, modifier = Modifier.fillMaxWidth()) { Text("تحديد الموقع") }
            return@Column
        }

        val qibla = QiblaCalculator.bearing(loc.latitude, loc.longitude)
        val distance = QiblaCalculator.distanceKm(loc.latitude, loc.longitude)
        val compass by rememberCompass(loc.latitude, loc.longitude)
        val heading = compass.headingTrue
        val delta = heading?.let { QiblaCalculator.signedDelta(it.toDouble(), qibla) }
        val aligned = delta != null && abs(delta) <= 3.0

        SectionCard {
            Text(loc.displayName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "زاوية القبلة: ${qibla.roundToInt()}° من الشمال (${QiblaCalculator.cardinalAr(qibla)})",
                style = MaterialTheme.typography.titleMedium,
            )
            Text("المسافة إلى الكعبة المشرفة: ${distance.roundToInt()} كم", style = MaterialTheme.typography.bodyMedium)
        }

        if (!compass.sensorAvailable) {
            InfoBanner(
                "جهازك لا يحتوي على مستشعر البوصلة (المغناطيسي). يمكنك استخدام الزاوية أعلاه مع بوصلة خارجية: " +
                    "وجّه الشمال الحقيقي ثم دُر ${qibla.roundToInt()}° مع عقارب الساعة.",
                warning = true,
            )
        }

        CompassDial(qibla = qibla.toFloat(), heading = heading, aligned = aligned)

        if (heading != null) {
            Text(
                if (aligned) "أنت تتجه نحو القبلة ✓" else {
                    val d = delta!!
                    val dir = if (d > 0) "يميناً" else "يساراً"
                    "أدر الهاتف ${abs(d).roundToInt()}° $dir"
                },
                style = MaterialTheme.typography.titleLarge,
                color = if (aligned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "اتجاه الهاتف الحالي: ${heading.roundToInt()}° (نسبةً للشمال الحقيقي)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        } else if (compass.sensorAvailable) {
            Text("جارٍ قراءة المستشعر… حرّك الهاتف قليلاً.", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }

        if (compass.needsCalibration) {
            InfoBanner(
                "دقة البوصلة منخفضة. عايرها بتحريك الهاتف في الهواء على شكل رقم 8 عدة مرات، وابتعد عن المعادن والمغناطيس والأجهزة الكهربائية.",
                warning = true,
            )
        }
        if (compass.fieldAbnormal) {
            InfoBanner(
                "المجال المغناطيسي حولك غير طبيعي (${compass.fieldStrength?.roundToInt()} µT بينما الطبيعي نحو 25–65). " +
                    "قد يكون الاتجاه خاطئاً، ابتعد عن مصدر التشويش أو عايِر البوصلة.",
                warning = true,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onOpenLocation) { Text("تغيير الموقع") }
        }
        InfoBanner("للتأكد: يُحسب الاتجاه رياضياً (دائرة عظمى) إلى إحداثيات الكعبة 21.4225°ش 39.8262°ق، ثم يُصحَّح بقراءة مستشعرات الجهاز وانحراف المجال المغناطيسي.")
    }
}

@Composable
private fun CompassDial(qibla: Float, heading: Float?, aligned: Boolean) {
    val measurer = rememberTextMeasurer()
    val ring = MaterialTheme.colorScheme.outline
    val surface = MaterialTheme.colorScheme.surface
    val onSurface = MaterialTheme.colorScheme.onSurface
    val primary = MaterialTheme.colorScheme.primary
    val goldColor = Gold
    val h = heading ?: 0f

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxWidth(0.92f).aspectRatio(1f)) {
            val c = center
            val radius = size.minDimension / 2f * 0.94f

            drawCircle(color = surface, radius = radius, center = c)
            drawCircle(color = if (aligned) primary else goldColor, radius = radius, center = c, style = Stroke(width = 6f))
            drawCircle(color = ring.copy(alpha = 0.4f), radius = radius * 0.72f, center = c, style = Stroke(width = 2f))

            // Dial: rotates opposite to the phone heading so "N" always points to true north.
            rotate(degrees = -h, pivot = c) {
                for (deg in 0 until 360 step 10) {
                    val major = deg % 90 == 0
                    val len = if (major) radius * 0.12f else radius * 0.06f
                    val a = Math.toRadians(deg.toDouble() - 90.0)
                    val outer = Offset(c.x + (radius * 0.97f * cos(a)).toFloat(), c.y + (radius * 0.97f * sin(a)).toFloat())
                    val inner = Offset(c.x + ((radius * 0.97f - len) * cos(a)).toFloat(), c.y + ((radius * 0.97f - len) * sin(a)).toFloat())
                    drawLine(color = if (deg == 0) Color(0xFFD64545) else ring, start = inner, end = outer, strokeWidth = if (major) 5f else 2f)
                }
                val labels = listOf(0 to "ش", 90 to "شرق", 180 to "ج", 270 to "غرب")
                for ((deg, text) in labels) {
                    val a = Math.toRadians(deg.toDouble() - 90.0)
                    val r = radius * 0.78f
                    val layout = measurer.measure(
                        text,
                        TextStyle(color = if (deg == 0) Color(0xFFD64545) else onSurface, fontSize = 16.sp, fontWeight = FontWeight.Bold),
                    )
                    val pos = Offset(
                        c.x + (r * cos(a)).toFloat() - layout.size.width / 2f,
                        c.y + (r * sin(a)).toFloat() - layout.size.height / 2f,
                    )
                    rotate(degrees = h, pivot = Offset(pos.x + layout.size.width / 2f, pos.y + layout.size.height / 2f)) {
                        drawText(layout, topLeft = pos)
                    }
                }

                // Qibla marker on the dial at the qibla bearing
                rotate(degrees = qibla, pivot = c) {
                    val tip = Offset(c.x, c.y - radius * 0.86f)
                    val path = Path().apply {
                        moveTo(tip.x, tip.y)
                        lineTo(c.x - radius * 0.07f, c.y - radius * 0.62f)
                        lineTo(c.x + radius * 0.07f, c.y - radius * 0.62f)
                        close()
                    }
                    drawLine(color = goldColor, start = c, end = Offset(c.x, c.y - radius * 0.62f), strokeWidth = 8f)
                    drawPath(path, color = goldColor)
                    drawCircle(color = IslamicGreen, radius = radius * 0.085f, center = Offset(c.x, c.y - radius * 0.94f))
                    drawCircle(color = goldColor, radius = radius * 0.085f, center = Offset(c.x, c.y - radius * 0.94f), style = Stroke(width = 4f))
                }
            }

            // Fixed phone-forward indicator at the top
            val mark = Path().apply {
                moveTo(c.x, c.y - radius - 4f)
                lineTo(c.x - 14f, c.y - radius + 22f)
                lineTo(c.x + 14f, c.y - radius + 22f)
                close()
            }
            drawPath(mark, color = if (aligned) primary else onSurface)
            drawCircle(color = if (aligned) primary else onSurface, radius = 7f, center = c)
        }
    }
}

