package com.herotoner.heroazan.alarms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.herotoner.heroazan.data.ReminderDao
import com.herotoner.heroazan.data.ReminderEntity
import com.herotoner.heroazan.data.SettingsRepository
import com.herotoner.heroazan.domain.PrayerEngine
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.Prayer
import java.time.Instant
import java.time.ZoneId

/**
 * Programs every alarm: one per prayer (next occurrence) plus the user's reminders.
 * Call [rescheduleAll] whenever location, calculation settings, alert modes or reminders
 * change, after an alarm fires, and after boot / date / time-zone changes.
 */
class AlarmScheduler(
    private val context: Context,
    private val settings: SettingsRepository,
    private val reminders: ReminderDao,
) {
    private val alarmManager get() = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    suspend fun rescheduleAll(from: Instant = Instant.now()) {
        schedulePrayers(from)
        scheduleReminders(from)
    }

    private suspend fun schedulePrayers(from: Instant) {
        val s = settings.current()
        val loc = s.location
        if (loc == null) {
            Prayer.entries.forEach { cancel(prayerRequestCode(it), AdhanAlarmReceiver::class.java) }
            return
        }
        val zone = loc.zone()
        val upcoming = PrayerEngine.upcomingPerPrayer(from, loc.latitude, loc.longitude, zone, s.calc)
        for (p in Prayer.entries) {
            val code = prayerRequestCode(p)
            if (s.alertModeOf(p) == AlertMode.OFF) {
                cancel(code, AdhanAlarmReceiver::class.java)
                continue
            }
            val at = upcoming.getValue(p)
            val intent = Intent(context, AdhanAlarmReceiver::class.java)
                .putExtra(EXTRA_PRAYER, p.key)
                .putExtra(EXTRA_SCHEDULED_AT, at.toEpochMilli())
            set(code, at, PendingIntent.getBroadcast(context, code, intent, FLAGS))
        }
    }

    private suspend fun scheduleReminders(from: Instant) {
        val s = settings.current()
        val zone = ZoneId.systemDefault()
        for (r in reminders.getAll()) {
            val code = reminderRequestCode(r.id)
            if (!r.enabled) {
                cancel(code, ReminderAlarmReceiver::class.java)
                continue
            }
            val at = nextReminderTime(r, from, zone, s) ?: run {
                cancel(code, ReminderAlarmReceiver::class.java)
                null
            } ?: continue
            val intent = Intent(context, ReminderAlarmReceiver::class.java).putExtra(EXTRA_REMINDER_ID, r.id)
            set(code, at, PendingIntent.getBroadcast(context, code, intent, FLAGS))
        }
    }

    private fun nextReminderTime(
        r: ReminderEntity,
        from: Instant,
        zone: ZoneId,
        s: com.herotoner.heroazan.model.AppSettings,
    ): Instant? {
        if (ReminderKind.fromName(r.kind) != ReminderKind.PRAYER_BEFORE) {
            return ReminderTimes.nextDaily(from, r.hour, r.minute, zone)
        }
        val loc = s.location ?: return null
        val prayer = Prayer.fromKey(r.prayerKey) ?: return null
        val prayerZone = loc.zone()
        val today = from.atZone(prayerZone).toLocalDate()
        for (d in 0..2) {
            val day = PrayerEngine.compute(loc.latitude, loc.longitude, today.plusDays(d.toLong()), prayerZone, s.calc)
            val at = day.timeOf(prayer).minusSeconds(r.minutesBefore * 60L)
            if (at.isAfter(from)) return at
        }
        return null
    }

    private fun set(requestCode: Int, at: Instant, pi: PendingIntent) {
        val millis = at.toEpochMilli()
        try {
            if (canScheduleExact()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            } else {
                // Exact-alarm permission not granted: the system may delay this by minutes.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }

    private fun cancel(requestCode: Int, receiver: Class<*>) {
        val pi = PendingIntent.getBroadcast(context, requestCode, Intent(context, receiver), FLAGS_NO_CREATE)
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
        }
    }

    companion object {
        const val EXTRA_PRAYER = "prayer"
        const val EXTRA_SCHEDULED_AT = "scheduled_at"
        const val EXTRA_REMINDER_ID = "reminder_id"
        private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        private const val FLAGS_NO_CREATE = PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE

        fun prayerRequestCode(p: Prayer) = 100 + p.ordinal
        fun reminderRequestCode(id: Int) = 1000 + id
    }
}
