package com.herotoner.heroazan.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import com.herotoner.heroazan.R
import com.herotoner.heroazan.model.ThemeMode

val IslamicGreen = Color(0xFF0B3D2E)
val IslamicGreenLight = Color(0xFF145C45)
val Gold = Color(0xFFC9A24B)
val GoldLight = Color(0xFFF3E3B3)

private val LightColors = lightColorScheme(
    primary = IslamicGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6EBE0),
    onPrimaryContainer = Color(0xFF062A20),
    secondary = Color(0xFF8A6D1F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF6EBC8),
    onSecondaryContainer = Color(0xFF3B2E06),
    background = Color(0xFFF7F5EE),
    onBackground = Color(0xFF15231D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF15231D),
    surfaceVariant = Color(0xFFEDE8D8),
    onSurfaceVariant = Color(0xFF4A5650),
    outline = Color(0xFF8B958F),
    error = Color(0xFFB3261E),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF45B88F),
    onPrimary = Color(0xFF042017),
    primaryContainer = Color(0xFF14402F),
    onPrimaryContainer = Color(0xFFCDEBDD),
    secondary = Gold,
    onSecondary = Color(0xFF2B2105),
    secondaryContainer = Color(0xFF4A3B0E),
    onSecondaryContainer = GoldLight,
    background = Color(0xFF0A1612),
    onBackground = Color(0xFFEDEFE9),
    surface = Color(0xFF12241D),
    onSurface = Color(0xFFEDEFE9),
    surfaceVariant = Color(0xFF1B3329),
    onSurfaceVariant = Color(0xFFB7C4BC),
    outline = Color(0xFF6F8077),
    error = Color(0xFFF2B8B5),
)

val CairoFamily = FontFamily(
    Font(R.font.cairo_regular, FontWeight.Normal),
    Font(R.font.cairo_semibold, FontWeight.SemiBold),
    Font(R.font.cairo_bold, FontWeight.Bold),
)

val QuranFamily = FontFamily(Font(R.font.amiri_quran, FontWeight.Normal))

private fun typography(): Typography {
    val base = Typography()
    fun TextStyle.cairo() = copy(fontFamily = CairoFamily)
    return Typography(
        displayLarge = base.displayLarge.cairo(), displayMedium = base.displayMedium.cairo(), displaySmall = base.displaySmall.cairo(),
        headlineLarge = base.headlineLarge.cairo(), headlineMedium = base.headlineMedium.cairo(), headlineSmall = base.headlineSmall.cairo(),
        titleLarge = base.titleLarge.cairo().copy(fontWeight = FontWeight.Bold),
        titleMedium = base.titleMedium.cairo().copy(fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.cairo().copy(fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.cairo().copy(fontSize = 17.sp, lineHeight = 26.sp),
        bodyMedium = base.bodyMedium.cairo().copy(fontSize = 15.sp, lineHeight = 22.sp),
        bodySmall = base.bodySmall.cairo(),
        labelLarge = base.labelLarge.cairo(), labelMedium = base.labelMedium.cairo(), labelSmall = base.labelSmall.cairo(),
    )
}

@Composable
fun HeroAzanTheme(
    themeMode: ThemeMode,
    fontScale: Float,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val density = LocalDensity.current
    // The user's in-app font size multiplies the system font scale.
    val scaled = Density(density.density, density.fontScale * fontScale)
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalDensity provides scaled,
    ) {
        MaterialTheme(
            colorScheme = if (dark) DarkColors else LightColors,
            typography = typography(),
            content = content,
        )
    }
}

@Composable
@ReadOnlyComposable
fun isDarkTheme(): Boolean = MaterialTheme.colorScheme.background.red < 0.3f
