package com.herotoner.heroazan.ui

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.herotoner.heroazan.domain.PrayerEngine
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.DayPrayerTimes
import com.herotoner.heroazan.model.NextPrayer
import com.herotoner.heroazan.model.Prayer
import java.time.Instant

data class PrayerUiState(
    val today: DayPrayerTimes,
    val next: NextPrayer,
    val current: Prayer?,
)

/**
 * Prayer state for the current second. Returns null when there is no saved location
 * (we never show invented times) or when the sun does not rise/set normally at that latitude.
 */
@Composable
fun rememberPrayerUi(settings: AppSettings, now: Instant): PrayerUiState? {
    val loc = settings.location ?: return null
    val zone = loc.zone()
    val date = now.atZone(zone).toLocalDate()
    val today = remember(loc.latitude, loc.longitude, zone, date, settings.methodId, settings.madhabId, settings.offsets) {
        runCatching { PrayerEngine.compute(loc.latitude, loc.longitude, date, zone, settings.calc) }.getOrNull()
    } ?: return null
    return runCatching {
        PrayerUiState(
            today = today,
            next = PrayerEngine.nextPrayer(now, loc.latitude, loc.longitude, zone, settings.calc),
            current = PrayerEngine.currentPrayer(now, loc.latitude, loc.longitude, zone, settings.calc),
        )
    }.getOrNull()
}

fun openExactAlarmSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }
}

fun openBatterySettings(context: Context) {
    val i = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(i) }
}

fun openAppNotificationSettings(context: Context) {
    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(i) }
}

fun openAppDetails(context: Context) {
    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(i) }
}

@Suppress("unused")
private fun alarmManager(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
