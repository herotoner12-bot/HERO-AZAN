package com.herotoner.heroazan.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroazan.data.AdhkarRepository
import com.herotoner.heroazan.heroApp
import kotlinx.coroutines.launch

private fun iconFor(id: String): ImageVector = when (id) {
    "morning" -> Icons.Filled.WbSunny
    "evening" -> Icons.Filled.NightsStay
    "after_prayer" -> Icons.Filled.Mosque
    else -> Icons.Filled.Bedtime
}

@Composable
fun AdhkarListScreen(onOpen: (String) -> Unit) {
    val repo = LocalContext.current.heroApp.adhkar
    val data by produceState<AdhkarRepository.Data?>(null) { value = repo.load() }

    Column(
        Modifier.fillMaxSize().padding(ScreenPadding),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الأذكار", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        val d = data
        if (d == null) {
            Text("جارٍ التحميل…")
        } else {
            d.sections.forEach { sec ->
                SectionCard(modifier = Modifier.clickable { onOpen(sec.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(iconFor(sec.id), size = 48.dp)
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(sec.ar, style = MaterialTheme.typography.titleMedium)
                            Text("${sec.items.size} ذكراً", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            Text(
                "المصدر: ${d.source}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun AdhkarSectionScreen(vm: AppViewModel, sectionId: String, onBack: () -> Unit) {
    val repo = LocalContext.current.heroApp.adhkar
    val data by produceState<AdhkarRepository.Data?>(null) { value = repo.load() }
    val section = data?.sections?.firstOrNull { it.id == sectionId }
    val progress by remember(sectionId) { vm.adhkarProgress(sectionId) }.collectAsState(initial = emptyMap())
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            HeroTopBar(
                title = section?.ar ?: "الأذكار",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { vm.resetAdhkar(sectionId) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "إعادة العدّاد من البداية")
                    }
                },
            )
        },
    ) { padding ->
        if (section == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { Text("جارٍ التحميل…") }
            return@Scaffold
        }
        val done = section.items.indices.count { (progress[it] ?: 0) >= section.items[it].count }
        val firstUnfinished = section.items.indices.firstOrNull { (progress[it] ?: 0) < section.items[it].count }

        Column(Modifier.fillMaxSize().padding(padding)) {
            Column(Modifier.padding(horizontal = ScreenPadding, vertical = 8.dp)) {
                Text("أنجزت $done من ${section.items.size}", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = { if (section.items.isEmpty()) 0f else done.toFloat() / section.items.size },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                )
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = ListContentPadding,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                itemsIndexed(section.items, key = { index, _ -> "dhikr-$index" }) { index, dhikr ->
                    val count = progress[index] ?: 0
                    val finished = count >= dhikr.count
                    val bg by animateColorAsState(
                        if (finished) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        label = "dhikrBg",
                    )
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            dhikr.text,
                            fontSize = 22.sp,
                            lineHeight = 38.sp,
                            textAlign = TextAlign.Justify,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("التكرار: ${dhikr.count}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (finished) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = "تم", tint = MaterialTheme.colorScheme.primary)
                            }
                            Button(
                                onClick = {
                                    if (!finished) vm.setAdhkarCount(sectionId, index, count + 1)
                                },
                                enabled = !finished,
                            ) { Text(if (finished) "تم" else "$count / ${dhikr.count}  اضغط للعدّ") }
                        }
                    }
                }
                item(key = "source") {
                    Text(
                        "المصدر: ${data?.source ?: ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(ScreenPadding),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    modifier = Modifier.weight(1f),
                    onClick = { scope.launch { listState.animateScrollToItem(0) } },
                ) { Text("من البداية") }
                Button(
                    modifier = Modifier.weight(1f),
                    enabled = firstUnfinished != null,
                    onClick = { firstUnfinished?.let { scope.launch { listState.animateScrollToItem(it) } } },
                ) { Text(if (firstUnfinished == null) "اكتملت الأذكار" else "التالي") }
            }
        }
    }
}
