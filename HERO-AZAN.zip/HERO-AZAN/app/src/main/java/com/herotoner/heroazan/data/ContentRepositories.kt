package com.herotoner.heroazan.data

import android.content.Context
import com.herotoner.heroazan.model.LocationSource
import com.herotoner.heroazan.model.UserLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// ------------------------------------------------------------------ Syria locations

data class Governorate(val id: String, val ar: String, val en: String, val capitalAr: String)

data class Place(
    val gov: String,
    val ar: String,
    val en: String,
    val lat: Double,
    val lon: Double,
    /** city | place | village | neighborhood */
    val type: String,
    /** parent city, only for neighborhoods */
    val parentCity: String?,
)

/**
 * Offline Syria location database (assets/data/syria_locations.json).
 * Every entry has its own real coordinates; places without a verified Arabic name or
 * coordinates are not included (see tools/build_data.py and README).
 */
class LocationsRepository(private val context: Context) {

    data class Data(val governorates: List<Governorate>, val places: List<Place>)

    @Volatile
    private var cache: Data? = null

    suspend fun load(): Data = withContext(Dispatchers.IO) { cache ?: parse().also { cache = it } }

    private fun parse(): Data {
        val text = context.assets.open("data/syria_locations.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(text)
        val govArr = root.getJSONArray("governorates")
        val governorates = (0 until govArr.length()).map { i ->
            val o = govArr.getJSONObject(i)
            Governorate(o.getString("id"), o.getString("ar"), o.getString("en"), o.getString("capitalAr"))
        }
        val placeArr = root.getJSONArray("places")
        val places = (0 until placeArr.length()).map { i ->
            val o = placeArr.getJSONObject(i)
            Place(
                gov = o.getString("g"),
                ar = o.getString("ar"),
                en = o.getString("en"),
                lat = o.getDouble("lat"),
                lon = o.getDouble("lon"),
                type = o.getString("t"),
                parentCity = if (o.has("c")) o.getString("c") else null,
            )
        }
        return Data(governorates, places)
    }

    fun toUserLocation(gov: Governorate, place: Place): UserLocation {
        val isArea = place.type == "neighborhood"
        return UserLocation(
            id = "preset:${gov.id}:${place.en}:${place.lat}:${place.lon}",
            govAr = gov.ar,
            cityAr = if (isArea) (place.parentCity ?: place.ar) else place.ar,
            areaAr = if (isArea) place.ar else null,
            latitude = place.lat,
            longitude = place.lon,
            zoneId = "Asia/Damascus",
            source = LocationSource.PRESET,
        )
    }

    /** Nearest *city* within [maxKm] of the point, used to label GPS fixes ("قرب حلب"). */
    fun nearestCity(places: List<Place>, lat: Double, lon: Double, maxKm: Double = 40.0): Pair<Place, Double>? {
        var best: Place? = null
        var bestKm = Double.MAX_VALUE
        for (p in places) {
            if (p.type != "city") continue
            val d = haversineKm(lat, lon, p.lat, p.lon)
            if (d < bestKm) {
                bestKm = d
                best = p
            }
        }
        return if (best != null && bestKm <= maxKm) best to bestKm else null
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dPhi = Math.toRadians(lat2 - lat1)
        val dLam = Math.toRadians(lon2 - lon1)
        val a = sin(dPhi / 2) * sin(dPhi / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLam / 2) * sin(dLam / 2)
        return 2 * 6371.0088 * atan2(sqrt(a), sqrt(1 - a))
    }
}

// ------------------------------------------------------------------ Quran

data class SurahInfo(val id: Int, val ar: String, val translit: String, val meccan: Boolean, val ayahCount: Int)

data class AyahRef(val surah: Int, val ayah: Int, val surahName: String, val text: String)

/** Quran text from assets/quran/{surah}.json (Uthmani script, 114 surahs, 6236 ayahs). */
class QuranRepository(private val context: Context) {

    @Volatile
    private var surahCache: List<SurahInfo>? = null

    private val verseCache = object : LinkedHashMap<Int, List<String>>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, List<String>>?): Boolean = size > 6
    }

    suspend fun surahs(): List<SurahInfo> = withContext(Dispatchers.IO) {
        surahCache ?: run {
            val text = context.assets.open("data/surahs.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(text)
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SurahInfo(o.getInt("id"), o.getString("ar"), o.getString("tr"), o.getString("type") == "meccan", o.getInt("n"))
            }
            surahCache = list
            list
        }
    }

    suspend fun verses(surah: Int): List<String> = withContext(Dispatchers.IO) {
        synchronized(verseCache) { verseCache[surah] } ?: run {
            val text = context.assets.open("quran/$surah.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(text)
            val list = (0 until arr.length()).map { arr.getString(it) }
            synchronized(verseCache) { verseCache[surah] = list }
            list
        }
    }

    suspend fun verse(surah: Int, ayah: Int): String? = verses(surah).getOrNull(ayah - 1)

    /** The standard basmala text, taken from the data itself (Al-Fatiha, ayah 1). */
    suspend fun basmala(): String = verses(1).first()

    /**
     * Deterministic "ayah of the day": walks through all 6236 ayahs in a fixed
     * pseudo-random order (a full cycle never repeats) and skips very short ayahs.
     */
    suspend fun ayahOfTheDay(date: LocalDate): AyahRef {
        val all = surahs()
        val total = all.sumOf { it.ayahCount }
        var g = Math.floorMod(date.toEpochDay() * 4093L, total.toLong()).toInt()
        repeat(12) {
            val ref = locate(all, g)
            val text = verse(ref.first, ref.second).orEmpty()
            if (text.trim().split(Regex("\\s+")).size >= 6) {
                return AyahRef(ref.first, ref.second, all[ref.first - 1].ar, text)
            }
            g = (g + 1) % total
        }
        val ref = locate(all, g)
        return AyahRef(ref.first, ref.second, all[ref.first - 1].ar, verse(ref.first, ref.second).orEmpty())
    }

    private fun locate(all: List<SurahInfo>, globalIndex: Int): Pair<Int, Int> {
        var remaining = globalIndex
        for (s in all) {
            if (remaining < s.ayahCount) return s.id to (remaining + 1)
            remaining -= s.ayahCount
        }
        return 1 to 1
    }
}

// ------------------------------------------------------------------ Adhkar

data class Dhikr(val text: String, val count: Int)

data class AdhkarSection(val id: String, val ar: String, val items: List<Dhikr>)

class AdhkarRepository(private val context: Context) {

    data class Data(val source: String, val sections: List<AdhkarSection>)

    @Volatile
    private var cache: Data? = null

    suspend fun load(): Data = withContext(Dispatchers.IO) {
        cache ?: run {
            val text = context.assets.open("data/adhkar.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(text)
            val secArr = root.getJSONArray("sections")
            val sections = (0 until secArr.length()).map { i ->
                val o = secArr.getJSONObject(i)
                val itemArr = o.getJSONArray("items")
                AdhkarSection(
                    o.getString("id"),
                    o.getString("ar"),
                    (0 until itemArr.length()).map { j ->
                        val it = itemArr.getJSONObject(j)
                        Dhikr(it.getString("t"), it.getInt("c").coerceAtLeast(1))
                    },
                )
            }
            Data(root.getString("source"), sections).also { cache = it }
        }
    }
}
