package com.herotoner.heroazan.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroazan.R
import com.herotoner.heroazan.alarms.Notifications
import com.herotoner.heroazan.data.AyahRef
import com.herotoner.heroazan.domain.ArabicFormats
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AlertMode
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.Prayer
import com.herotoner.heroazan.ui.theme.Gold
import com.herotoner.heroazan.ui.theme.GoldLight
import com.herotoner.heroazan.ui.theme.QuranFamily
import java.time.Duration
import java.time.LocalDate

@Composable
fun HomeScreen(
    vm: AppViewModel,
    settings: AppSettings,
    onOpenLocation: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenReminders: () -> Unit,
    onOpenQibla: () -> Unit,
    onOpenAdhkar: (String) -> Unit,
    onOpenAyah: (Int, Int) -> Unit,
) {
    val now by vm.now.collectAsState()
    val ui = rememberPrayerUi(settings, now)
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ScreenPadding, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // 1. Logo + title + settings
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo_mark), contentDescription = "شعار HERO AZAN", modifier = Modifier.size(44.dp))
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text("HERO AZAN", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                Text("مواقيت الصلاة والأذان", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onOpenReminders) {
                Icon(Icons.Filled.AccessTime, contentDescription = "التذكيرات")
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "الإعدادات")
            }
        }

        // 2. Location + dates
        val zone = settings.location?.zone() ?: java.time.ZoneId.systemDefault()
        val date = now.atZone(zone).toLocalDate()
        SectionCard {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onOpenLocation),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Gold)
                Spacer(Modifier.size(8.dp))
                Text(
                    settings.location?.displayName ?: "اختر موقعك لعرض المواقيت",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = onOpenLocation) { Text("تغيير") }
            }
            GoldDivider()
            Text(ArabicFormats.hijri(date, settings.hijriAdjust), style = MaterialTheme.typography.titleMedium)
            Text(ArabicFormats.gregorian(date), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (settings.location == null) {
            InfoBanner(
                "لا توجد مواقيت لأن الموقع غير محدد. اختر محافظتك ومدينتك أو استخدم GPS، ولن يعرض التطبيق أي أوقات تقريبية أو ثابتة.",
                warning = true,
            )
            Button(onClick = onOpenLocation, modifier = Modifier.fillMaxWidth()) { Text("تحديد الموقع") }
        } else if (ui == null) {
            InfoBanner("تعذّر حساب المواقيت لهذا الموقع. تحقق من الإحداثيات أو اختر موقعاً آخر.", warning = true)
        } else {
            // 3 + 4. Next prayer hero with countdown
            val remaining = Duration.between(now, ui.next.time).seconds
            HeroCard {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("الصلاة القادمة", color = GoldLight, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        ui.next.prayer.arabic,
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        ArabicFormats.clock(ui.next.time, zone, settings.use24h) + if (ui.next.isTomorrow) " (غداً)" else "",
                        color = Gold,
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(
                        ArabicFormats.countdown(remaining),
                        color = Color.White,
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Text("المتبقي: ${ArabicFormats.remainingWords(remaining)}", color = GoldLight, style = MaterialTheme.typography.bodySmall)
                }
            }

            // 5 + 6. Prayer table
            SectionCard(title = "مواقيت اليوم") {
                Prayer.entries.forEachIndexed { index, p ->
                    PrayerRow(
                        prayer = p,
                        time = ArabicFormats.clock(ui.today.timeOf(p), zone, settings.use24h),
                        isCurrent = ui.current == p,
                        isNext = ui.next.prayer == p && !ui.next.isTomorrow,
                        mode = settings.alertModeOf(p),
                    )
                    if (index < Prayer.entries.size - 1) GoldDivider()
                }
                Text(
                    "الشروق: " + ArabicFormats.clock(ui.today.sunrise, zone, settings.use24h),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // 7. Adhan status
        AdhanStatusCard(vm, settings)

        // 8. Ayah of the day
        AyahOfTheDayCard(vm, onOpenAyah)

        // 9 + 10. Shortcuts
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            ShortcutTile("أذكار الصباح", Icons.Filled.WbSunny, Modifier.weight(1f)) { onOpenAdhkar("morning") }
            ShortcutTile("أذكار المساء", Icons.Filled.NightsStay, Modifier.weight(1f)) { onOpenAdhkar("evening") }
            ShortcutTile("اتجاه القبلة", Icons.Filled.Explore, Modifier.weight(1f), onOpenQibla)
        }
        Spacer(Modifier.size(8.dp))
    }
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, isCurrent: Boolean, isNext: Boolean, mode: AlertMode) {
    val highlight = when {
        isNext -> MaterialTheme.colorScheme.primaryContainer
        isCurrent -> MaterialTheme.colorScheme.secondaryContainer
        else -> Color.Transparent
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(highlight)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (mode == AlertMode.OFF) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive,
            contentDescription = mode.arabic,
            tint = if (mode == AlertMode.OFF) MaterialTheme.colorScheme.outline else Gold,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.size(10.dp))
        Column(Modifier.weight(1f)) {
            Text(prayer.arabic, style = MaterialTheme.typography.titleMedium)
            val tag = when {
                isNext -> "القادمة"
                isCurrent -> "الحالية"
                else -> null
            }
            if (tag != null) Text(tag, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
        Text(time, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun AdhanStatusCard(vm: AppViewModel, settings: AppSettings) {
    val context = LocalContext.current
    val enabled = Prayer.entries.count { settings.alertModeOf(it) != AlertMode.OFF }
    val full = Prayer.entries.count { settings.alertModeOf(it) == AlertMode.ADHAN_FULL }
    val tick by vm.resumeTick.collectAsState()
    val notificationsOk = remember(tick) { Notifications.areEnabled(context) }
    val exactOk = remember(tick) { vm.canScheduleExact() }
    val hasAdhanFile = remember { vm.availableAdhans().isNotEmpty() || settings.adhanChoices.values.any { it.type.name == "CUSTOM" } }

    SectionCard(title = "حالة الأذان") {
        val summary = when {
            settings.location == null -> "غير مفعّل: حدّد الموقع أولاً"
            enabled == 0 -> "الأذان متوقف لجميع الصلوات"
            else -> "مفعّل لـ $enabled من 5 صلوات (أذان كامل: $full)"
        }
        Text(summary, style = MaterialTheme.typography.bodyLarge)
        if (!notificationsOk) {
            InfoBanner("الإشعارات معطّلة لهذا التطبيق، لن يظهر أي تنبيه ولن يعمل الأذان بشكل موثوق.", warning = true)
            OutlinedButton(onClick = { openAppNotificationSettings(context) }) { Text("فتح إعدادات الإشعارات") }
        }
        if (!exactOk) {
            InfoBanner("صلاحية «التنبيهات والمنبهات الدقيقة» غير ممنوحة، لذلك قد يتأخر الأذان عدة دقائق. فعّلها ليعمل في الوقت بالضبط.", warning = true)
            OutlinedButton(onClick = { openExactAlarmSettings(context) }) { Text("منح صلاحية التنبيه الدقيق") }
        }
        if (full > 0 && !hasAdhanFile) {
            InfoBanner("لم تتم إضافة ملف أذان بعد، سيُستخدم صوت تنبيه افتراضي. أضف ملف أذان من الإعدادات > صوت الأذان.", warning = true)
        }
        Text(
            "للاعتماد الكامل على الأذان والشاشة مغلقة، استثنِ التطبيق من توفير البطارية في إعدادات الهاتف.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TextButton(onClick = { openBatterySettings(context) }) { Text("فتح إعدادات البطارية") }
    }
}

@Composable
private fun AyahOfTheDayCard(vm: AppViewModel, onOpenAyah: (Int, Int) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val repo = context.heroApp.quran
    val ayah by produceState<AyahRef?>(initialValue = null, LocalDate.now()) {
        value = runCatching { repo.ayahOfTheDay(LocalDate.now()) }.getOrNull()
    }
    SectionCard(title = "آية اليوم") {
        val a = ayah
        if (a == null) {
            Text("جارٍ التحميل…")
        } else {
            Text(
                a.text + " ﴿${a.ayah}﴾",
                fontFamily = QuranFamily,
                fontSize = 26.sp,
                lineHeight = 46.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "سورة ${a.surahName} • الآية ${a.ayah}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            val shareString = "${a.text} ﴿${a.ayah}﴾\n[سورة ${a.surahName} - الآية ${a.ayah}]\nHERO AZAN"
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { shareText(context, shareString) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp)); Text("مشاركة")
                }
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(shareString)) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp)); Text("نسخ")
                }
            }
            Button(
                onClick = { onOpenAyah(a.surah, a.ayah) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(),
            ) { Text("الانتقال إلى السورة") }
        }
    }
}

@Composable
private fun ShortcutTile(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        IconBadge(icon)
        Text(label, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
    }
}
