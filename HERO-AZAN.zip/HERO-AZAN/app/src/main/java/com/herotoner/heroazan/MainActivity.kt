package com.herotoner.heroazan

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.ui.AdhanSettingsScreen
import com.herotoner.heroazan.ui.AdhkarListScreen
import com.herotoner.heroazan.ui.AdhkarSectionScreen
import com.herotoner.heroazan.ui.AppViewModel
import com.herotoner.heroazan.ui.CalcSettingsScreen
import com.herotoner.heroazan.ui.FavoriteAyahsScreen
import com.herotoner.heroazan.ui.HomeScreen
import com.herotoner.heroazan.ui.LocationScreen
import com.herotoner.heroazan.ui.PrayerScreen
import com.herotoner.heroazan.ui.PrivacyScreen
import com.herotoner.heroazan.ui.QiblaScreen
import com.herotoner.heroazan.ui.QuranListScreen
import com.herotoner.heroazan.ui.QuranReaderScreen
import com.herotoner.heroazan.ui.RemindersScreen
import com.herotoner.heroazan.ui.SettingsScreen
import com.herotoner.heroazan.ui.theme.HeroAzanTheme

private object Routes {
    const val HOME = "home"
    const val PRAYER = "prayer"
    const val QIBLA = "qibla"
    const val QURAN = "quran"
    const val ADHKAR = "adhkar"
    const val ADHKAR_SECTION = "adhkar/{id}"
    const val READER = "reader/{surah}/{ayah}"
    const val FAV_AYAHS = "favAyahs"
    const val SETTINGS = "settings"
    const val LOCATION = "location"
    const val CALC = "calc"
    const val ADHAN = "adhanSettings"
    const val REMINDERS = "reminders"
    const val PRIVACY = "privacy"

    fun adhkar(id: String) = "adhkar/$id"
    fun reader(surah: Int, ayah: Int) = "reader/$surah/$ayah"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.HOME, "الرئيسية", Icons.Filled.Home),
    BottomItem(Routes.PRAYER, "الصلاة", Icons.Filled.AccessTime),
    BottomItem(Routes.QIBLA, "القبلة", Icons.Filled.Explore),
    BottomItem(Routes.QURAN, "القرآن", Icons.Filled.MenuBook),
    BottomItem(Routes.ADHKAR, "الأذكار", Icons.Filled.AutoStories),
)

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    /** A notification tap can ask to open a specific destination. */
    private var pendingDestination: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingDestination = intent?.getStringExtra(EXTRA_DESTINATION)

        setContent {
            val settings by vm.settings.collectAsState()
            val s = settings
            HeroAzanTheme(themeMode = s?.themeMode ?: com.herotoner.heroazan.model.ThemeMode.SYSTEM, fontScale = s?.fontScale ?: 1f) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (s == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("HERO AZAN") }
                    } else {
                        AppRoot(vm, s, pendingDestination)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDestination = intent.getStringExtra(EXTRA_DESTINATION)
        recreate()
    }

    override fun onResume() {
        super.onResume()
        vm.resumeTick.value = vm.resumeTick.value + 1
        // The exact-alarm permission may have just been granted; re-program with the best mode.
        vm.refreshAlarms()
    }

    companion object {
        const val EXTRA_DESTINATION = "destination"
    }
}

@Composable
private fun AppRoot(vm: AppViewModel, settings: AppSettings, startDestination: String?) {
    val nav = rememberNavController()
    val context = LocalContext.current

    // Ask for the notification permission once (Android 13+); the app explains what happens if refused.
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(startDestination) {
        when (startDestination) {
            "prayer" -> nav.navigate(Routes.PRAYER)
            "adhkar" -> nav.navigate(Routes.ADHKAR)
            "quran" -> nav.navigate(Routes.QURAN)
        }
    }

    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = currentRoute in bottomItems.map { it.route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = { navigateTop(nav, item.route) },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) {
                HomeScreen(
                    vm = vm,
                    settings = settings,
                    onOpenLocation = { nav.navigate(Routes.LOCATION) },
                    onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                    onOpenReminders = { nav.navigate(Routes.REMINDERS) },
                    onOpenQibla = { navigateTop(nav, Routes.QIBLA) },
                    onOpenAdhkar = { id -> nav.navigate(Routes.adhkar(id)) },
                    onOpenAyah = { surah, ayah -> nav.navigate(Routes.reader(surah, ayah)) },
                )
            }
            composable(Routes.PRAYER) {
                PrayerScreen(
                    vm, settings,
                    onOpenLocation = { nav.navigate(Routes.LOCATION) },
                    onOpenCalcSettings = { nav.navigate(Routes.CALC) },
                    onOpenAdhanSettings = { nav.navigate(Routes.ADHAN) },
                )
            }
            composable(Routes.QIBLA) { QiblaScreen(settings, onOpenLocation = { nav.navigate(Routes.LOCATION) }) }
            composable(Routes.QURAN) {
                QuranListScreen(
                    vm, settings,
                    onOpenSurah = { surah, ayah -> nav.navigate(Routes.reader(surah, ayah)) },
                    onOpenFavorites = { nav.navigate(Routes.FAV_AYAHS) },
                )
            }
            composable(Routes.ADHKAR) { AdhkarListScreen(onOpen = { nav.navigate(Routes.adhkar(it)) }) }
            composable(
                Routes.ADHKAR_SECTION,
                arguments = listOf(navArgument("id") { type = NavType.StringType }),
            ) { entry ->
                AdhkarSectionScreen(vm, entry.arguments?.getString("id") ?: "morning", onBack = { nav.popBackStack() })
            }
            composable(
                Routes.READER,
                arguments = listOf(
                    navArgument("surah") { type = NavType.IntType },
                    navArgument("ayah") { type = NavType.IntType },
                ),
            ) { entry ->
                QuranReaderScreen(
                    vm, settings,
                    surahId = (entry.arguments?.getInt("surah") ?: 1).coerceIn(1, 114),
                    startAyah = (entry.arguments?.getInt("ayah") ?: 1).coerceAtLeast(1),
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.FAV_AYAHS) {
                FavoriteAyahsScreen(vm, onOpen = { s, a -> nav.navigate(Routes.reader(s, a)) }, onBack = { nav.popBackStack() })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    vm, settings,
                    onBack = { nav.popBackStack() },
                    onOpenLocation = { nav.navigate(Routes.LOCATION) },
                    onOpenCalc = { nav.navigate(Routes.CALC) },
                    onOpenAdhan = { nav.navigate(Routes.ADHAN) },
                    onOpenReminders = { nav.navigate(Routes.REMINDERS) },
                    onOpenPrivacy = { nav.navigate(Routes.PRIVACY) },
                )
            }
            composable(Routes.LOCATION) { LocationScreen(vm, settings, onDone = { nav.popBackStack() }) }
            composable(Routes.CALC) { CalcSettingsScreen(vm, settings, onBack = { nav.popBackStack() }) }
            composable(Routes.ADHAN) { AdhanSettingsScreen(vm, settings, onBack = { nav.popBackStack() }) }
            composable(Routes.REMINDERS) { RemindersScreen(vm, onBack = { nav.popBackStack() }) }
            composable(Routes.PRIVACY) { PrivacyScreen(onBack = { nav.popBackStack() }) }
        }
    }
}

private fun navigateTop(nav: NavHostController, route: String) {
    nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
