package com.herotoner.heroazan.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.herotoner.heroazan.data.Governorate
import com.herotoner.heroazan.data.LocationsRepository
import com.herotoner.heroazan.data.Place
import com.herotoner.heroazan.heroApp
import com.herotoner.heroazan.model.AppSettings
import com.herotoner.heroazan.model.LocationSource
import com.herotoner.heroazan.model.UserLocation
import kotlinx.coroutines.launch

/** Normalises Arabic text for searching (removes tashkeel, unifies alef / ya / ta marbuta). */
private fun norm(s: String): String = s
    .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
    .replace(Regex("[أإآٱ]"), "ا")
    .replace('ى', 'ي')
    .replace('ة', 'ه')
    .lowercase()
    .trim()

@Composable
fun LocationScreen(vm: AppViewModel, settings: AppSettings, onDone: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("سوريا", "GPS", "يدوي", "المفضلة")

    Scaffold(topBar = { HeroTopBar("اختيار الموقع", onBack = onDone) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> SyriaPicker(vm, settings, onDone)
                1 -> GpsTab(vm, onDone)
                2 -> ManualTab(vm, onDone)
                else -> FavoritesTab(vm, settings, onDone)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SyriaPicker(vm: AppViewModel, settings: AppSettings, onDone: () -> Unit) {
    val repo = vm.locationsRepo
    val data by produceState<LocationsRepository.Data?>(null) { value = repo.load() }
    var govId by rememberSaveable { mutableStateOf("aleppo") }
    var query by rememberSaveable { mutableStateOf("") }

    val d = data
    if (d == null) {
        Text("جارٍ تحميل قاعدة المواقع…", Modifier.padding(ScreenPadding))
        return
    }
    val gov = d.governorates.firstOrNull { it.id == govId } ?: d.governorates.first()
    val inGov = remember(gov.id) { d.places.filter { it.gov == gov.id } }

    // Step 1: governorate chips
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = ListContentPadding,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text("1) المحافظة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
        item {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                d.governorates.forEach { g ->
                    FilterChip(
                        selected = g.id == gov.id,
                        onClick = { govId = g.id; query = "" },
                        label = { Text(g.ar) },
                    )
                }
            }
        }
        item {
            Text("2) المدينة / البلدة / المنطقة", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("ابحث في ${gov.ar}") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        val q = norm(query)
        // Neighbourhoods are shown as "areas" of their parent city.
        val filtered = inGov.filter { q.isEmpty() || norm(it.ar).contains(q) || it.en.lowercase().contains(q) }
        val cities = filtered.filter { it.type == "city" }
        val areas = filtered.filter { it.type == "neighborhood" }
        val others = filtered.filter { it.type != "city" && it.type != "neighborhood" }

        if (filtered.isEmpty()) {
            item { InfoBanner("لا نتائج. لم تُضف أماكن بلا إحداثيات موثوقة، جرّب «GPS» أو «يدوي».", warning = true) }
        }
        if (areas.isNotEmpty()) {
            item { Text("مناطق وأحياء", style = MaterialTheme.typography.titleSmall) }
            items(areas, key = { "a:${it.en}:${it.lat}" }) { p -> PlaceRow(vm, repo, gov, p, "حي في ${p.parentCity ?: ""}", settings, onDone) }
        }
        if (cities.isNotEmpty()) {
            item { Text("مدن", style = MaterialTheme.typography.titleSmall) }
            items(cities, key = { "c:${it.en}:${it.lat}" }) { p -> PlaceRow(vm, repo, gov, p, null, settings, onDone) }
        }
        if (others.isNotEmpty()) {
            // very long lists are capped when not searching, to keep the UI fast
            val shown = if (q.isEmpty()) others.take(150) else others.take(300)
            item { Text("بلدات وقرى (${others.size})", style = MaterialTheme.typography.titleSmall) }
            items(shown, key = { "o:${it.en}:${it.lat}:${it.lon}" }) { p -> PlaceRow(vm, repo, gov, p, null, settings, onDone) }
            if (shown.size < others.size) item {
                Text("اكتب في البحث لعرض باقي النتائج…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PlaceRow(
    vm: AppViewModel,
    repo: LocationsRepository,
    gov: Governorate,
    place: Place,
    subtitle: String?,
    settings: AppSettings,
    onDone: () -> Unit,
) {
    val loc = repo.toUserLocation(gov, place)
    val selected = settings.location?.id == loc.id
    val favorites by vm.favoriteLocations.collectAsState()
    val isFav = favorites.any { it.id == loc.id }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { vm.setLocation(loc); onDone() }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(place.ar, style = MaterialTheme.typography.titleMedium, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Text(
                listOfNotNull(subtitle, "%.4f, %.4f".format(java.util.Locale.US, place.lat, place.lon)).joinToString(" • "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        IconButton(onClick = { if (isFav) vm.deleteFavorite(loc.id) else vm.saveFavorite(loc) }) {
            Icon(if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder, contentDescription = "المفضلة")
        }
    }
}

@Composable
private fun GpsTab(vm: AppViewModel, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<UserLocation?>(null) }

    fun run() {
        busy = true
        status = "جارٍ تحديد الموقع…"
        scope.launch {
            when (val r = vm.fetchGps()) {
                is GpsResult.Success -> { pending = r.location; status = null }
                GpsResult.NoPermission -> status = "لم يتم منح إذن الموقع."
                GpsResult.LocationOff -> status = "خدمة الموقع (GPS) مغلقة في الهاتف. فعّلها ثم أعد المحاولة."
                GpsResult.Failed -> status = "تعذّر الحصول على موقع في الوقت المحدد. جرّب في مكان مفتوح أو اختر الموقع يدوياً."
            }
            busy = false
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) run() else status = "رُفض إذن الموقع. يمكنك اختيار الموقع يدوياً من تبويب «سوريا» دون GPS."
    }

    Column(Modifier.fillMaxSize().padding(ScreenPadding), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoBanner("يُستخدم الموقع مرة واحدة فقط لحساب المواقيت والقبلة ويُحفظ على جهازك، ولا يُرسل إلى أي خادم.")
        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (context.heroApp.gps.hasPermission()) run()
                else launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            },
        ) {
            Icon(Icons.Filled.MyLocation, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.size(8.dp))
            Text("استخدام موقعي الحالي (GPS)")
        }
        status?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
        pending?.let { loc ->
            SectionCard(title = "تم تحديد موقعك") {
                Text(loc.displayName, style = MaterialTheme.typography.titleMedium)
                Text("%.5f, %.5f".format(java.util.Locale.US, loc.latitude, loc.longitude), style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.setLocation(loc); onDone() }) { Text("استخدام هذا الموقع") }
                    OutlinedButton(onClick = { vm.saveFavorite(loc); vm.setLocation(loc); onDone() }) { Text("حفظ كمفضلة") }
                }
            }
        }
    }
}

@Composable
private fun ManualTab(vm: AppViewModel, onDone: () -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var lat by rememberSaveable { mutableStateOf("") }
    var lon by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(ScreenPadding), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoBanner("أدخل الإحداثيات بالأرقام العشرية (مثال حلب: 36.2000 و 37.1600). تجدها في خرائط جوجل بالضغط المطوّل على المكان.")
        OutlinedTextField(name, { name = it }, label = { Text("اسم المكان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            lat, { lat = it }, label = { Text("خط العرض (Latitude)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            lon, { lon = it }, label = { Text("خط الطول (Longitude)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val la = lat.trim().replace('٫', '.').replace(',', '.').toDoubleOrNull()
                val lo = lon.trim().replace('٫', '.').replace(',', '.').toDoubleOrNull()
                when {
                    name.isBlank() -> error = "اكتب اسماً للمكان."
                    la == null || lo == null -> error = "أدخل إحداثيات صحيحة بالأرقام."
                    la !in -90.0..90.0 || lo !in -180.0..180.0 -> error = "الإحداثيات خارج النطاق المسموح."
                    else -> {
                        val loc = UserLocation(
                            id = "manual:${"%.4f".format(java.util.Locale.US, la)}:${"%.4f".format(java.util.Locale.US, lo)}",
                            govAr = null, cityAr = name.trim(), areaAr = null,
                            latitude = la, longitude = lo, zoneId = null, source = LocationSource.MANUAL,
                        )
                        vm.setLocation(loc)
                        onDone()
                    }
                }
            },
        ) { Text("حفظ واستخدام") }
    }
}

@Composable
private fun FavoritesTab(vm: AppViewModel, settings: AppSettings, onDone: () -> Unit) {
    val favorites by vm.favoriteLocations.collectAsState()
    val current = settings.location
    LazyColumn(Modifier.fillMaxSize(), contentPadding = ListContentPadding, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (current != null && favorites.none { it.id == current.id }) {
            item {
                OutlinedButton(onClick = { vm.saveFavorite(current) }, modifier = Modifier.fillMaxWidth()) {
                    Text("حفظ «${current.displayName}» كموقع مفضل")
                }
            }
        }
        if (favorites.isEmpty()) {
            item { Text("لا توجد مواقع مفضلة بعد. اضغط النجمة بجانب أي مكان لحفظه.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(favorites, key = { it.id }) { f ->
            val loc = f.toUserLocation()
            Row(
                Modifier.fillMaxWidth().clickable { vm.setLocation(loc); onDone() }.padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(loc.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "%.4f, %.4f".format(java.util.Locale.US, loc.latitude, loc.longitude),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { vm.deleteFavorite(f.id) }) { Icon(Icons.Filled.Delete, contentDescription = "حذف") }
            }
        }
    }
}

