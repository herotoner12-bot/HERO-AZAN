package com.herotoner.heroazan.alarms

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import com.herotoner.heroazan.model.AdhanChoice

/**
 * Plays one adhan recording. Used by the foreground service (real prayer time) and by the
 * settings screen (preview / test button).
 *
 * Volume: the app volume (0..1) is applied on top of the system stream volume, so the
 * app can only make the adhan quieter, never override the phone's own volume setting.
 */
class AdhanPlayer(private val context: Context, private val library: AdhanLibrary) {

    private var player: MediaPlayer? = null

    /** @return true when a real adhan recording is playing, false when the fallback sound was used. */
    fun play(choice: AdhanChoice, volume: Float, short: Boolean = false, onDone: () -> Unit): Boolean {
        stop()
        val source = library.resolve(choice)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(attrs)
            when (source) {
                is AdhanSource.Asset -> context.assets.openFd(source.path).use {
                    mp.setDataSource(it.fileDescriptor, it.startOffset, it.length)
                }
                is AdhanSource.Custom -> mp.setDataSource(context, source.uri)
                null -> mp.setDataSource(context, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            }
            mp.setVolume(volume, volume)
            mp.setOnCompletionListener { release(); onDone() }
            mp.setOnErrorListener { _, _, _ -> release(); onDone(); true }
            mp.prepare()
            mp.start()
            player = mp
            source != null
        } catch (e: Exception) {
            runCatching { mp.release() }
            player = null
            onDone()
            false
        }
    }

    fun stop() {
        player?.let { runCatching { if (it.isPlaying) it.stop() } ; runCatching { it.release() } }
        player = null
    }

    private fun release() {
        runCatching { player?.release() }
        player = null
    }
}
