package com.herotoner.heroazan.alarms

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId

/** Pure time arithmetic for reminders (unit-tested). */
object ReminderTimes {
    /** Next occurrence of [hour]:[minute] strictly after [now] in [zone] (DST-safe via ZonedDateTime). */
    fun nextDaily(now: Instant, hour: Int, minute: Int, zone: ZoneId): Instant {
        val local = now.atZone(zone)
        var candidate = local.toLocalDate().atTime(LocalTime.of(hour, minute)).atZone(zone)
        if (!candidate.toInstant().isAfter(now)) candidate = candidate.plusDays(1)
        return candidate.toInstant()
    }
}
