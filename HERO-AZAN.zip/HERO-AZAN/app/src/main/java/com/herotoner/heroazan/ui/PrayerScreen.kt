package com.herotoner.heroazan.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.herotoner.heroazan.domain.ArabicFormats
import com.herotoner.heroazan.domain.PrayerEngine
import com.herotoner.heroazan.model.AppSettings

@Composable
fun PrayerScreen(
    vm: AppViewModel,
    settings: AppSettings,
    onOpenLocation: () -> Unit,
    onOpenCalcSettings: () -> Unit,
    onOpenAdhanSettings: () -> Unit,
) {
    val now by vm.now.collectAsState()
    var dayOffset by rememberSaveable { mutableIntStateOf(0) }
    val loc = settings.location

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(ScreenPadding),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("مواقيت الصلاة", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)

        if (loc == null) {
            InfoBanner("حدّد موقعك أولاً. لا يعرض التطبيق أي مواقيت دون إحداثيات حقيقية.", warning = true)
            Button(onClick = onOpenLocation, modifier = Modifier.fillMaxWidth()) { Text("تحديد الموقع") }
            return@Column
        }

        val zone = loc.zone()
        val date = now.atZone(zone).toLocalDate().plusDays(dayOffset.toLong())
        val times = remember(loc.latitude, loc.longitude, zone, date, settings.methodId, settings.madhabId, settings.offsets) {
            runCatching { PrayerEngine.compute(loc.latitude, loc.longitude, date, zone, settings.calc) }.getOrNull()
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { dayOffset-- }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "اليوم السابق")
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ArabicFormats.gregorian(date), style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
                    Text(ArabicFormats.hijri(date, settings.hijriAdjust), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { dayOffset++ }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "اليوم التالي")
                }
            }
            if (dayOffset != 0) TextButton(onClick = { dayOffset = 0 }, modifier = Modifier.fillMaxWidth()) { Text("العودة إلى اليوم") }
            Text(loc.displayName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (times == null) {
            InfoBanner("تعذّر حساب المواقيت لهذا الموقع/التاريخ.", warning = true)
        } else {
            SectionCard(title = "الأوقات") {
                TimeRow("الفجر", ArabicFormats.clock(times.fajr, zone, settings.use24h), settings.offsets.fajr)
                GoldDivider()
                TimeRow("الشروق", ArabicFormats.clock(times.sunrise, zone, settings.use24h), settings.offsets.sunrise)
                GoldDivider()
                TimeRow("الظهر", ArabicFormats.clock(times.dhuhr, zone, settings.use24h), settings.offsets.dhuhr)
                GoldDivider()
                TimeRow("العصر", ArabicFormats.clock(times.asr, zone, settings.use24h), settings.offsets.asr)
                GoldDivider()
                TimeRow("المغرب", ArabicFormats.clock(times.maghrib, zone, settings.use24h), settings.offsets.maghrib)
                GoldDivider()
                TimeRow("العشاء", ArabicFormats.clock(times.isha, zone, settings.use24h), settings.offsets.isha)
            }
        }

        val method = settings.calc.method
        val madhab = settings.calc.madhab
        SectionCard(title = "طريقة الحساب") {
            Text(method.arabic, style = MaterialTheme.typography.titleMedium)
            Text(method.details, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("العصر: ${madhab.arabic}", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenCalcSettings) { Text("تغيير الطريقة والفروق") }
                OutlinedButton(onClick = onOpenAdhanSettings) { Text("إعدادات الأذان") }
            }
        }

        InfoBanner(
            "هذه المواقيت محسوبة فلكياً بمكتبة Adhan حسب إحداثيات موقعك وطريقة الحساب المختارة. قد تختلف دقيقة أو دقيقتين عن التقويم المحلي المعتمد، " +
                "قارنها بتقويم الأوقاف في بلدك وعدّل «فروق الدقائق» لتطابقه.",
        )
    }
}

@Composable
private fun TimeRow(name: String, time: String, offset: Int) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleMedium)
            if (offset != 0) {
                val sign = if (offset > 0) "+" else ""
                Text("فرق يدوي: $sign$offset د", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
        }
        Text(time, style = MaterialTheme.typography.titleLarge)
    }
}

