// Generates reference prayer times / qibla values with the reference JavaScript
// implementation of Adhan (npm adhan 4.x, same author as the Kotlin/Java library)
// so the Kotlin unit tests can compare the Android engine against an independent run.
// usage: TZ=UTC node gen_reference_times.js <adhan module dir> <out.json>
const adhan = require(process.argv[2]);
const fs = require('fs');
const places = [
  ["حلب", 36.2, 37.16], ["الشيخ مقصود", 36.23611, 37.15167], ["الأشرفية", 36.22778, 37.14306],
  ["عفرين", 36.51194, 36.86944], ["دمشق", 33.51306, 36.29194], ["حمص", 34.73333, 36.71667],
  ["اللاذقية", 35.52, 35.7781],
];
const dates = [[2026, 6, 21], [2026, 12, 21], [2027, 3, 29]];
const methods = { MWL: "MuslimWorldLeague", EGYPTIAN: "Egyptian", UMM_AL_QURA: "UmmAlQura", KARACHI: "Karachi" };
const out = [];
for (const [name, lat, lon] of places) {
  const c = new adhan.Coordinates(lat, lon);
  for (const [y, m, d] of dates) {
    for (const [key, fn] of Object.entries(methods)) {
      for (const madhab of ["SHAFI", "HANAFI"]) {
        const p = adhan.CalculationMethod[fn]();
        p.madhab = madhab === "HANAFI" ? adhan.Madhab.Hanafi : adhan.Madhab.Shafi;
        const t = new adhan.PrayerTimes(c, new Date(y, m - 1, d), p);
        out.push({ place: name, lat, lon, date: `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`,
          method: key, madhab,
          fajr: t.fajr.toISOString(), sunrise: t.sunrise.toISOString(), dhuhr: t.dhuhr.toISOString(),
          asr: t.asr.toISOString(), maghrib: t.maghrib.toISOString(), isha: t.isha.toISOString() });
      }
    }
  }
}
const qibla = places.map(([name, lat, lon]) => ({ place: name, lat, lon, bearing: adhan.Qibla(new adhan.Coordinates(lat, lon)) }));
fs.writeFileSync(process.argv[3], JSON.stringify({ generatedBy: "npm adhan " + require(process.argv[2] + "/package.json").version, times: out, qibla }, null, 0));
console.log("rows", out.length, "qibla", qibla.length);
