#!/usr/bin/env python3
"""Generates the offline data assets bundled with HERO AZAN.

Sources (all fetched via npm / GitHub raw, nothing invented here):
  * Syria places  : npm @geomelon/syria (CC0, Wikidata-derived)  + a few
                    hand-verified additions (see EXTRA_PLACES, each with its source)
  * Quran text    : npm all-quran  (Uthmani text from The Noble Qur'an Encyclopedia)
  * Adhkar        : GitHub rn0x/Adhkar-json (text of Hisn al-Muslim, no-licence/free use)

usage: build_data.py <node_modules dir> <adhkar_json> <assets dir>
"""
import json, sys, os

NM, ADHKAR, OUT = sys.argv[1], sys.argv[2], sys.argv[3]

# ---------------------------------------------------------------- Syria
GOVS = [  # id, Arabic, dataset English name, capital's English name in the dataset
    ("aleppo", "حلب", "Aleppo Governorate", "Aleppo"),
    ("damascus", "دمشق", "Damascus Governorate", "Damascus"),
    ("rif-dimashq", "ريف دمشق", "Rif Dimashq Governorate", "Douma"),
    ("homs", "حمص", "Homs Governorate", "Homs"),
    ("hama", "حماة", "Hama Governorate", "Hama"),
    ("latakia", "اللاذقية", "Latakia Governorate", "Latakia"),
    ("tartus", "طرطوس", "Tartus Governorate", "Tartus"),
    ("idlib", "إدلب", "Idlib Governorate", "Idlib"),
    ("raqqa", "الرقة", "Raqqa Governorate", "Raqqa"),
    ("deir-ez-zor", "دير الزور", "Deir ez-Zor Governorate", "Deir ez-Zor"),
    ("hasakah", "الحسكة", "Hasakah Governorate", "Hasakah"),
    ("daraa", "درعا", "Daraa Governorate", "Daraa"),
    ("suwayda", "السويداء", "Suwayda Governorate", "As-Suwayda"),
    ("quneitra", "القنيطرة", "Quneitra Governorate", "Quneitra"),
]
# Arabic names missing/odd in the Wikidata export for major cities (names only, never coordinates)
AR_OVERRIDE = {"Damascus": "دمشق", "Homs": "حمص", "Gabala": "جبلة"}

def dms(d, m, s):
    return round(d + m / 60 + s / 3600, 5)

# Places that are not in the dataset but whose coordinates were read from the
# English Wikipedia infobox of the place (value, source url) -- see README.
EXTRA_PLACES = [
    # (gov id, Arabic, English, lat, lon, type, source)
    ("aleppo", "الشيخ مقصود", "Sheikh Maqsood", 36.23611, 37.15167, "neighborhood",
     "https://en.wikipedia.org/wiki/Sheikh_Maqsood"),
    ("aleppo", "الأشرفية", "Ashrafiyah (Aleppo)", 36.22778, 37.14306, "neighborhood",
     "https://en.wikipedia.org/wiki/Ashrafiyah,_Aleppo"),
    ("aleppo", "منبج", "Manbij", dms(36, 31, 41), dms(37, 57, 17), "city",
     "https://en.wikipedia.org/wiki/Manbij (36°31′41″N 37°57′17″E)"),
    ("suwayda", "السويداء", "As-Suwayda", 32.7125, 36.56667, "city",
     "https://en.wikipedia.org/wiki/Suwayda (32°42′45″N 36°34′00″E)"),
]
BBOX = (32.0, 37.6, 35.5, 42.6)  # lat_min, lat_max, lon_min, lon_max (Syria, generous)

d = json.load(open(f"{NM}/@geomelon/syria/data.json", encoding="utf-8"))
region_by_name = {r["name"]: r for r in d["regions"]}
gov_index = {}
for i, (gid, ar, en, cap) in enumerate(GOVS):
    assert en in region_by_name, en
    gov_index[region_by_name[en]["id"]] = gid

CITY_T = {"city", "big city", "small city", "border city", "national capital", "largest city"}
places, seen = [], set()
cap_found = {}
for c in d["cities"]:
    gid = gov_index.get(c.get("regionId"))
    if not gid or c.get("latitude") is None or c.get("longitude") is None:
        continue
    lat, lon = c["latitude"], c["longitude"]
    if not (BBOX[0] <= lat <= BBOX[1] and BBOX[2] <= lon <= BBOX[3]):
        continue
    en = c["name"]
    ar = AR_OVERRIDE.get(en) or c.get("translations", {}).get("ar")
    if not ar:
        continue  # never show a place without a verified Arabic name
    types = set(c.get("settlementTypes") or [])
    t = "city" if types & CITY_T else ("village" if "village" in types else "place")
    key = (gid, ar, round(lat, 3), round(lon, 3))
    if key in seen:
        continue
    seen.add(key)
    places.append({"g": gid, "ar": ar, "en": en, "lat": round(lat, 5), "lon": round(lon, 5),
                   "t": t, "p": c.get("population") or 0})
    for (g2, _, _, cap) in GOVS:
        if g2 == gid and en == cap:
            cap_found[gid] = len(places) - 1

for (gid, ar, en, lat, lon, t, src) in EXTRA_PLACES:
    places.append({"g": gid, "ar": ar, "en": en, "lat": lat, "lon": lon, "t": t, "p": 1, "src": src})

places.sort(key=lambda p: (-p["p"], p["ar"]))
govs_out = []
for (gid, ar, en, cap) in GOVS:
    match = [p for p in places if p["g"] == gid and p["en"] == cap]
    assert match, f"capital of {gid} ({cap}) not found"
    govs_out.append({"id": gid, "ar": ar, "en": en.replace(" Governorate", ""),
                     "capitalAr": match[0]["ar"], "capitalEn": cap})
for p in places:
    p.pop("p", None)
    if p["t"] == "neighborhood":
        p["c"] = "حلب"  # parent city (both verified neighborhoods are in Aleppo city)
os.makedirs(f"{OUT}/data", exist_ok=True)
json.dump({"source": "npm @geomelon/syria (CC0, Wikidata) + verified additions",
           "governorates": govs_out, "places": places},
          open(f"{OUT}/data/syria_locations.json", "w", encoding="utf-8"),
          ensure_ascii=False, separators=(",", ":"))
from collections import Counter
print("places:", len(places), Counter(p["g"] for p in places))

# ---------------------------------------------------------------- Quran
q = json.load(open(f"{NM}/all-quran/dist/quran.json", encoding="utf-8"))
assert len(q) == 114
os.makedirs(f"{OUT}/quran", exist_ok=True)
surahs, total = [], 0
for s in q:
    verses = [v["text"] for v in s["verses"]]
    assert [v["id"] for v in s["verses"]] == list(range(1, len(verses) + 1)), s["id"]
    assert len(verses) == s["total_verses"], s["id"]
    total += len(verses)
    json.dump(verses, open(f"{OUT}/quran/{s['id']}.json", "w", encoding="utf-8"),
              ensure_ascii=False, separators=(",", ":"))
    surahs.append({"id": s["id"], "ar": s["name"], "tr": s["transliteration"],
                   "type": s["type"], "n": len(verses)})
print("quran ayahs:", total)
assert total == 6236
json.dump(surahs, open(f"{OUT}/data/surahs.json", "w", encoding="utf-8"),
          ensure_ascii=False, separators=(",", ":"))

# ---------------------------------------------------------------- Adhkar
a = json.load(open(ADHKAR, encoding="utf-8"))
by_id = {x["id"]: x for x in a}
def items(cat_id):
    return [{"t": i["text"].strip(), "c": int(i["count"])} for i in by_id[cat_id]["array"]]
morning_evening = items(1)
sections = [
    {"id": "morning", "ar": "أذكار الصباح", "items": morning_evening},
    {"id": "evening", "ar": "أذكار المساء", "items": morning_evening},
    {"id": "after_prayer", "ar": "أذكار بعد الصلاة", "items": items(27)},
    {"id": "sleep", "ar": "أذكار النوم", "items": items(2)},
]
json.dump({"source": "حصن المسلم (سعيد بن علي بن وهف القحطاني) - نصوص من مستودع rn0x/Adhkar-json",
           "sections": sections},
          open(f"{OUT}/data/adhkar.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print({s["id"]: len(s["items"]) for s in sections})
